<?php
// ============================================
// iAcademy Lost & Found — API: Send Notification
// api/notify.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo    = getPDO();
$admin  = currentUser();
$userId  = (int)($_POST['user_id'] ?? 0);
$itemId  = (int)($_POST['item_id'] ?? 0);
$message = trim($_POST['message'] ?? '');
$redirect = $_POST['redirect'] ?? ("/admin/item-view.php?id=$itemId");

if ($userId && $message) {
    $pdo->prepare(
        "INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)"
    )->execute([$userId, 'Message from Admin', $message, 'info',
                $itemId ? "/user/item-view.php?id=$itemId" : null]);
}

header('Location: ' . $redirect . '&notified=1');
exit;
