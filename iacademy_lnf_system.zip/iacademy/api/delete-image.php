<?php
// ============================================
// iAcademy Lost & Found — API: Delete Image
// api/delete-image.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo      = getPDO();
$imageId  = (int)($_POST['image_id'] ?? 0);
$redirect = $_POST['redirect'] ?? '/admin/items.php';

if ($imageId) {
    $img = $pdo->prepare("SELECT * FROM item_images WHERE id = ?");
    $img->execute([$imageId]);
    $img = $img->fetch();

    if ($img) {
        // Delete file from disk
        $filePath = __DIR__ . '/../' . $img['image_path'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        $pdo->prepare("DELETE FROM item_images WHERE id = ?")->execute([$imageId]);
    }
}

header('Location: ' . $redirect);
exit;
