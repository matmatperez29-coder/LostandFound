-- ============================================
-- iAcademy Lost & Found — Database Setup
-- Database: iacademy_lnf  (matches config/db.php)
-- Run: mysql -u root -p < iacademy_lnf.sql
-- Default admin login:
--   Email:    admin@iacademy.edu.ph
--   Password: password
-- ============================================

CREATE DATABASE IF NOT EXISTS `iacademy_lnf`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `iacademy_lnf`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- activity_log
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `actor_id`    int(10) UNSIGNED DEFAULT NULL,
  `action`      varchar(100) NOT NULL,
  `target_type` varchar(50)  DEFAULT NULL,
  `target_id`   int(10) UNSIGNED DEFAULT NULL,
  `meta`        longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `ip_address`  varchar(45)  DEFAULT NULL,
  `created_at`  timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_log_actor` (`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id`         int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       varchar(100) NOT NULL,
  `icon`       varchar(50)  DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `categories` (`id`, `name`, `icon`) VALUES
(1,'Electronics','laptop'),(2,'ID / Cards','id-card'),(3,'Clothing','shirt'),
(4,'Books / Notes','book'),(5,'Bags','backpack'),(6,'Keys','key'),
(7,'Accessories','watch'),(8,'Others','box');

-- users
CREATE TABLE IF NOT EXISTS `users` (
  `id`            int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id`    varchar(20)  DEFAULT NULL,
  `first_name`    varchar(80)  NOT NULL,
  `last_name`     varchar(80)  NOT NULL,
  `email`         varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role`          enum('admin','user') NOT NULL DEFAULT 'user',
  `avatar_path`   varchar(255) DEFAULT NULL,
  `is_active`     tinyint(1)   NOT NULL DEFAULT 1,
  `created_at`    timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at`    timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Default admin: admin@iacademy.edu.ph / password
INSERT IGNORE INTO `users` (`id`,`student_id`,`first_name`,`last_name`,`email`,`password_hash`,`role`,`is_active`)
VALUES (1,NULL,'System','Admin','admin@iacademy.edu.ph',
'$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin',1);

-- items
CREATE TABLE IF NOT EXISTS `items` (
  `id`             int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference_no`   varchar(20)  NOT NULL,
  `reported_by`    int(10) UNSIGNED NOT NULL,
  `category_id`    int(10) UNSIGNED NOT NULL,
  `item_name`      varchar(150) NOT NULL,
  `description`    text         DEFAULT NULL,
  `location_found` varchar(200) DEFAULT NULL,
  `date_reported`  date         NOT NULL,
  `date_found`     date         DEFAULT NULL,
  `status`         enum('lost','found','claimed','turned_in','disposed') NOT NULL DEFAULT 'lost',
  `is_archived`    tinyint(1)   NOT NULL DEFAULT 0,
  `created_at`     timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at`     timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_no` (`reference_no`),
  KEY `fk_items_user` (`reported_by`),
  KEY `fk_items_category` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- item_images
CREATE TABLE IF NOT EXISTS `item_images` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `item_id`     int(10) UNSIGNED NOT NULL,
  `image_path`  varchar(255) NOT NULL,
  `is_primary`  tinyint(1)   NOT NULL DEFAULT 0,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_images_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- claims
CREATE TABLE IF NOT EXISTS `claims` (
  `id`          int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `item_id`     int(10) UNSIGNED NOT NULL,
  `claimant_id` int(10) UNSIGNED NOT NULL,
  `proof_path`  varchar(255) DEFAULT NULL,
  `claim_note`  text         DEFAULT NULL,
  `status`      enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime     DEFAULT NULL,
  `admin_note`  text         DEFAULT NULL,
  `created_at`  timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_claims_item`     (`item_id`),
  KEY `fk_claims_claimant` (`claimant_id`),
  KEY `fk_claims_reviewer` (`reviewed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    int(10) UNSIGNED NOT NULL,
  `title`      varchar(150) NOT NULL,
  `message`    text         NOT NULL,
  `type`       enum('info','success','warning','error') NOT NULL DEFAULT 'info',
  `is_read`    tinyint(1)   NOT NULL DEFAULT 0,
  `link`       varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_notif_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Foreign Keys
ALTER TABLE `activity_log`
  ADD CONSTRAINT `fk_log_actor` FOREIGN KEY (`actor_id`) REFERENCES `users`(`id`) ON DELETE SET NULL;
ALTER TABLE `items`
  ADD CONSTRAINT `fk_items_user` FOREIGN KEY (`reported_by`) REFERENCES `users`(`id`),
  ADD CONSTRAINT `fk_items_category` FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`);
ALTER TABLE `item_images`
  ADD CONSTRAINT `fk_images_item` FOREIGN KEY (`item_id`) REFERENCES `items`(`id`) ON DELETE CASCADE;
ALTER TABLE `claims`
  ADD CONSTRAINT `fk_claims_item` FOREIGN KEY (`item_id`) REFERENCES `items`(`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_claims_claimant` FOREIGN KEY (`claimant_id`) REFERENCES `users`(`id`),
  ADD CONSTRAINT `fk_claims_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL;
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE;

COMMIT;
