<?php
// Root redirect — send guests to login, logged-in users to their dashboard
session_start();
if (isset($_SESSION['user_id'])) {
    $dest = ($_SESSION['role'] ?? 'user') === 'admin'
        ? '/admin/dashboard.php'
        : '/user/dashboard.php';
} else {
    $dest = '/auth/login.php';
}
header('Location: ' . $dest);
exit;
