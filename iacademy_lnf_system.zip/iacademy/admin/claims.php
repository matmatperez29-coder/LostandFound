<?php
// ============================================
// iAcademy Lost & Found — Admin Claims
// admin/claims.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();
$filter = $_GET['status'] ?? 'pending';

$where  = $filter !== 'all' ? "WHERE cl.status = ?" : "WHERE 1";
$params = $filter !== 'all' ? [$filter] : [];

$claims = $pdo->prepare(
    "SELECT cl.*, i.item_name, i.reference_no, i.status AS item_status,
            u.first_name, u.last_name, u.email, u.student_id
     FROM claims cl
     JOIN items i ON cl.item_id = i.id
     JOIN users u ON cl.claimant_id = u.id
     $where
     ORDER BY cl.created_at DESC"
);
$claims->execute($params);
$claims = $claims->fetchAll();

$pageTitle = 'Claims';
include __DIR__ . '/../includes/header.php';
?>

<!-- Filter Tabs -->
<div style="display:flex;gap:8px;margin-bottom:20px;">
  <?php foreach (['pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected','all'=>'All'] as $val=>$label): ?>
  <a href="?status=<?= $val ?>" class="btn <?= $filter === $val ? 'btn-primary' : 'btn-ghost' ?> btn-sm"><?= $label ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Item</th>
          <th>Ref #</th>
          <th>Claimant</th>
          <th>Student ID</th>
          <th>Status</th>
          <th>Submitted</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($claims as $cl): ?>
        <tr>
          <td style="font-weight:500"><?= htmlspecialchars($cl['item_name']) ?></td>
          <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($cl['reference_no']) ?></td>
          <td><?= htmlspecialchars($cl['first_name'].' '.$cl['last_name']) ?><br><span style="font-size:11px;color:var(--white-dim)"><?= htmlspecialchars($cl['email']) ?></span></td>
          <td style="color:var(--white-dim);font-size:12px"><?= htmlspecialchars($cl['student_id'] ?? '—') ?></td>
          <td><span class="badge badge-<?= $cl['status'] ?>"><?= ucfirst($cl['status']) ?></span></td>
          <td style="color:var(--white-dim);font-size:12px"><?= date('M d, Y H:i', strtotime($cl['created_at'])) ?></td>
          <td><a href="/admin/claim-review.php?id=<?= $cl['id'] ?>" class="btn btn-ghost btn-sm">Review</a></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($claims)): ?>
        <tr><td colspan="7" style="text-align:center;color:var(--white-dim);padding:40px">No <?= $filter !== 'all' ? $filter : '' ?> claims found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
