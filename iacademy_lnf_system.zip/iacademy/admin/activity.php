<?php
// ============================================
// iAcademy Lost & Found — Admin Activity Log
// admin/activity.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo    = getPDO();
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset  = ($page - 1) * $perPage;

$total = (int)$pdo->query("SELECT COUNT(*) FROM activity_log")->fetchColumn();
$pages = (int)ceil($total / $perPage);

$logs = $pdo->prepare(
    "SELECT al.*, u.first_name, u.last_name, u.email
     FROM activity_log al
     LEFT JOIN users u ON al.actor_id = u.id
     ORDER BY al.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$logs->execute();
$logs = $logs->fetchAll();

$actionColors = [
    'user.login'    => 'var(--success)',
    'user.logout'   => 'var(--white-dim)',
    'user.register' => 'var(--blue-accent)',
    'item.create'   => 'var(--success)',
    'item.update'   => 'var(--warning)',
    'claim.approved'=> 'var(--success)',
    'claim.rejected'=> 'var(--error)',
];

$pageTitle = 'Activity Log';
include __DIR__ . '/../includes/header.php';
?>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>IP Address</th></tr>
      </thead>
      <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
          <td style="font-size:12px;color:var(--white-dim);white-space:nowrap"><?= date('M d, Y H:i:s', strtotime($log['created_at'])) ?></td>
          <td>
            <?php if ($log['first_name']): ?>
            <div style="font-size:13px;font-weight:500"><?= htmlspecialchars($log['first_name'].' '.$log['last_name']) ?></div>
            <div style="font-size:11px;color:var(--white-dim)"><?= htmlspecialchars($log['email'] ?? '') ?></div>
            <?php else: ?>
            <span style="color:var(--white-dim);font-size:12px">System</span>
            <?php endif; ?>
          </td>
          <td>
            <code style="font-size:12px;color:<?= $actionColors[$log['action']] ?? 'var(--white-soft)' ?>;background:var(--white-ghost);padding:3px 8px;border-radius:4px;"><?= htmlspecialchars($log['action']) ?></code>
          </td>
          <td style="font-size:12px;color:var(--white-dim)">
            <?= htmlspecialchars($log['target_type'] ?? '') ?> <?= $log['target_id'] ? '#'.$log['target_id'] : '' ?>
          </td>
          <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($log['ip_address'] ?? '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($pages > 1): ?>
  <div class="pagination" style="padding:16px;">
    <?php for ($i = 1; $i <= min($pages, 10); $i++): ?>
    <a href="?page=<?= $i ?>" class="page-btn <?= $i === $page ? 'current' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
