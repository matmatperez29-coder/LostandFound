<?php
// ============================================
// iAcademy Lost & Found — Admin Add Item
// admin/item-add.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name     = trim($_POST['item_name']     ?? '');
    $category_id   = (int)($_POST['category_id']  ?? 0);
    $description   = trim($_POST['description']   ?? '');
    $location_found= trim($_POST['location_found']?? '');
    $date_reported = $_POST['date_reported']       ?? date('Y-m-d');
    $date_found    = $_POST['date_found']           ?? null;
    $status        = $_POST['status']              ?? 'found';

    if (!$item_name || !$category_id) {
        $error = 'Item name and category are required.';
    } else {
        // Generate reference number
        $ref = 'LNF-' . strtoupper(substr(date('Y'), 2)) . '-' . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);

        $user = currentUser();
        $stmt = $pdo->prepare(
            "INSERT INTO items (reference_no, reported_by, category_id, item_name, description,
             location_found, date_reported, date_found, status)
             VALUES (?,?,?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $ref, $user['id'], $category_id, $item_name, $description,
            $location_found ?: null, $date_reported, $date_found ?: null, $status
        ]);
        $itemId = $pdo->lastInsertId();

        // Handle image upload
        if (!empty($_FILES['images']['name'][0])) {
            $uploadDir = __DIR__ . '/../uploads/items/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

            $isPrimary = 1;
            foreach ($_FILES['images']['tmp_name'] as $idx => $tmp) {
                if (!$tmp) continue;
                $ext  = pathinfo($_FILES['images']['name'][$idx], PATHINFO_EXTENSION);
                $fname = $itemId . '_' . $idx . '_' . time() . '.' . strtolower($ext);
                if (move_uploaded_file($tmp, $uploadDir . $fname)) {
                    $pdo->prepare("INSERT INTO item_images (item_id, image_path, is_primary) VALUES (?,?,?)")
                        ->execute([$itemId, 'uploads/items/' . $fname, $isPrimary]);
                    $isPrimary = 0;
                }
            }
        }

        // Log activity
        $pdo->prepare("INSERT INTO activity_log (actor_id, action, target_type, target_id, ip_address) VALUES (?,'item.create','item',?,?)")
            ->execute([$user['id'], $itemId, $_SERVER['REMOTE_ADDR'] ?? null]);

        header('Location: /admin/item-view.php?id=' . $itemId . '&created=1');
        exit;
    }
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$pageTitle = 'Add Item';
include __DIR__ . '/../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="max-width:760px;">
  <div class="card">
    <div class="card-header" style="margin-bottom:24px;">
      <h2 class="card-title">New Item Entry</h2>
      <a href="/admin/items.php" class="btn btn-ghost btn-sm">← Back</a>
    </div>

    <form method="POST" enctype="multipart/form-data">
      <div class="grid-2">
        <div class="field">
          <label>Item Name *</label>
          <input type="text" name="item_name" required placeholder="e.g. Black Laptop Bag" value="<?= htmlspecialchars($_POST['item_name'] ?? '') ?>">
        </div>
        <div class="field">
          <label>Category *</label>
          <select name="category_id" required>
            <option value="">Select category</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="field">
        <label>Description</label>
        <textarea name="description" placeholder="Describe the item in detail — color, brand, distinguishing features..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
      </div>

      <div class="grid-2">
        <div class="field">
          <label>Location Found</label>
          <input type="text" name="location_found" placeholder="e.g. 4th Floor Hallway, Library" value="<?= htmlspecialchars($_POST['location_found'] ?? '') ?>">
        </div>
        <div class="field">
          <label>Status</label>
          <select name="status">
            <option value="found" <?= ($_POST['status'] ?? 'found') === 'found' ? 'selected' : '' ?>>Found</option>
            <option value="lost"  <?= ($_POST['status'] ?? '') === 'lost'  ? 'selected' : '' ?>>Lost (Reported)</option>
            <option value="turned_in" <?= ($_POST['status'] ?? '') === 'turned_in' ? 'selected' : '' ?>>Turned In</option>
          </select>
        </div>
      </div>

      <div class="grid-2">
        <div class="field">
          <label>Date Reported *</label>
          <input type="date" name="date_reported" required value="<?= htmlspecialchars($_POST['date_reported'] ?? date('Y-m-d')) ?>">
        </div>
        <div class="field">
          <label>Date Found</label>
          <input type="date" name="date_found" value="<?= htmlspecialchars($_POST['date_found'] ?? '') ?>">
        </div>
      </div>

      <div class="field">
        <label>Item Images (multiple allowed)</label>
        <input type="file" name="images[]" multiple accept="image/*" style="padding:10px;">
      </div>

      <div style="display:flex;gap:10px;margin-top:8px;">
        <button type="submit" class="btn btn-primary">Save Item</button>
        <a href="/admin/items.php" class="btn btn-ghost">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
