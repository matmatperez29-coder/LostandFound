<?php
// ============================================
// iAcademy Lost & Found — Admin Dashboard
// admin/dashboard.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();

// ── Stats ──
$stats = [];
$statQueries = [
    'total_items'    => "SELECT COUNT(*) FROM items WHERE is_archived = 0",
    'lost_items'     => "SELECT COUNT(*) FROM items WHERE status = 'lost' AND is_archived = 0",
    'found_items'    => "SELECT COUNT(*) FROM items WHERE status = 'found' AND is_archived = 0",
    'pending_claims' => "SELECT COUNT(*) FROM claims WHERE status = 'pending'",
    'claimed_items'  => "SELECT COUNT(*) FROM items WHERE status = 'claimed'",
    'total_users'    => "SELECT COUNT(*) FROM users WHERE role = 'user'",
];
foreach ($statQueries as $key => $sql) {
    $stats[$key] = (int)$pdo->query($sql)->fetchColumn();
}

// ── Recent items ──
$recentItems = $pdo->query(
    "SELECT i.*, c.name AS category, u.first_name, u.last_name
     FROM items i
     JOIN categories c ON i.category_id = c.id
     JOIN users u ON i.reported_by = u.id
     WHERE i.is_archived = 0
     ORDER BY i.created_at DESC LIMIT 8"
)->fetchAll();

// ── Pending claims ──
$pendingClaims = $pdo->query(
    "SELECT cl.*, i.item_name, i.reference_no,
            u.first_name, u.last_name, u.email
     FROM claims cl
     JOIN items i ON cl.item_id = i.id
     JOIN users u ON cl.claimant_id = u.id
     WHERE cl.status = 'pending'
     ORDER BY cl.created_at DESC LIMIT 6"
)->fetchAll();

// ── Category distribution ──
$categoryStats = $pdo->query(
    "SELECT c.name, COUNT(i.id) AS total
     FROM categories c
     LEFT JOIN items i ON i.category_id = c.id AND i.is_archived = 0
     GROUP BY c.id ORDER BY total DESC"
)->fetchAll();

$pageTitle = 'Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<!-- Stats Grid -->
<div class="grid-4" style="margin-bottom:28px;">
  <div class="stat-card">
    <div class="stat-label">Total Items</div>
    <div class="stat-value"><?= $stats['total_items'] ?></div>
    <div class="stat-sub">Active records</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Pending Claims</div>
    <div class="stat-value" style="color:var(--warning)"><?= $stats['pending_claims'] ?></div>
    <div class="stat-sub">Awaiting review</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Found Items</div>
    <div class="stat-value" style="color:var(--success)"><?= $stats['found_items'] ?></div>
    <div class="stat-sub">Available</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Registered Users</div>
    <div class="stat-value" style="color:var(--blue-accent)"><?= $stats['total_users'] ?></div>
    <div class="stat-sub">Members</div>
  </div>
</div>

<div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px; margin-bottom:28px;">

  <!-- Recent Items -->
  <div class="card">
    <div class="card-header">
      <h2 class="card-title">Recent Items</h2>
      <a href="/admin/items.php" class="btn btn-ghost btn-sm">View All</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Ref #</th>
            <th>Item</th>
            <th>Category</th>
            <th>Status</th>
            <th>Reported</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recentItems as $item): ?>
          <tr>
            <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($item['reference_no']) ?></td>
            <td style="font-weight:500;"><?= htmlspecialchars($item['item_name']) ?></td>
            <td style="color:var(--white-dim)"><?= htmlspecialchars($item['category']) ?></td>
            <td><span class="badge badge-<?= $item['status'] ?>"><?= ucfirst(str_replace('_',' ',$item['status'])) ?></span></td>
            <td style="color:var(--white-dim);font-size:12px"><?= date('M d, Y', strtotime($item['date_reported'])) ?></td>
            <td><a href="/admin/item-view.php?id=<?= $item['id'] ?>" class="btn btn-ghost btn-sm">View</a></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($recentItems)): ?>
          <tr><td colspan="6" style="text-align:center;color:var(--white-dim);padding:30px">No items yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Category Breakdown -->
  <div class="card">
    <div class="card-header">
      <h2 class="card-title">By Category</h2>
    </div>
    <?php foreach ($categoryStats as $cat): ?>
    <div style="margin-bottom:12px;">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
        <span><?= htmlspecialchars($cat['name']) ?></span>
        <span style="color:var(--blue-accent);font-weight:500"><?= $cat['total'] ?></span>
      </div>
      <div style="height:4px;background:var(--white-ghost);border-radius:2px;overflow:hidden;">
        <div style="height:100%;width:<?= $stats['total_items'] > 0 ? round(($cat['total']/$stats['total_items'])*100) : 0 ?>%;background:var(--blue-accent);border-radius:2px;transition:width .5s"></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

</div>

<!-- Pending Claims -->
<?php if (!empty($pendingClaims)): ?>
<div class="card">
  <div class="card-header">
    <h2 class="card-title">Pending Claims <span style="font-size:14px;font-family:var(--font-body);color:var(--warning);margin-left:8px"><?= count($pendingClaims) ?> awaiting</span></h2>
    <a href="/admin/claims.php" class="btn btn-ghost btn-sm">All Claims</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Item</th><th>Ref #</th><th>Claimant</th><th>Email</th><th>Submitted</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($pendingClaims as $cl): ?>
        <tr>
          <td style="font-weight:500"><?= htmlspecialchars($cl['item_name']) ?></td>
          <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($cl['reference_no']) ?></td>
          <td><?= htmlspecialchars($cl['first_name'].' '.$cl['last_name']) ?></td>
          <td style="color:var(--white-dim);font-size:12px"><?= htmlspecialchars($cl['email']) ?></td>
          <td style="color:var(--white-dim);font-size:12px"><?= date('M d, Y', strtotime($cl['created_at'])) ?></td>
          <td>
            <a href="/admin/claim-review.php?id=<?= $cl['id'] ?>" class="btn btn-primary btn-sm">Review</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
