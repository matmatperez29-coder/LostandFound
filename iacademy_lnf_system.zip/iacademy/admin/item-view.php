<?php
// ============================================
// iAcademy Lost & Found — Admin Item View
// admin/item-view.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();
$id  = (int)($_GET['id'] ?? 0);

$item = $pdo->prepare(
    "SELECT i.*, c.name AS category, u.first_name, u.last_name, u.email, u.student_id
     FROM items i
     JOIN categories c ON i.category_id = c.id
     JOIN users u ON i.reported_by = u.id
     WHERE i.id = ?"
);
$item->execute([$id]);
$item = $item->fetch();

if (!$item) { header('Location: /admin/items.php'); exit; }

$images = $pdo->prepare("SELECT * FROM item_images WHERE item_id = ? ORDER BY is_primary DESC");
$images->execute([$id]);
$images = $images->fetchAll();

$claims = $pdo->prepare(
    "SELECT cl.*, u.first_name, u.last_name, u.email, u.student_id
     FROM claims cl JOIN users u ON cl.claimant_id = u.id
     WHERE cl.item_id = ? ORDER BY cl.created_at DESC"
);
$claims->execute([$id]);
$claims = $claims->fetchAll();

$created = isset($_GET['created']);
$pageTitle = 'Item Details';
include __DIR__ . '/../includes/header.php';
?>

<?php if ($created): ?>
<div class="alert alert-success" style="margin-bottom:20px;">
  Item created successfully! Reference: <strong><?= htmlspecialchars($item['reference_no']) ?></strong>
</div>
<?php endif; ?>

<div style="display:flex;gap:8px;margin-bottom:20px;align-items:center;">
  <a href="/admin/items.php" class="btn btn-ghost btn-sm">← All Items</a>
  <a href="/admin/item-edit.php?id=<?= $id ?>" class="btn btn-primary btn-sm">Edit Item</a>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">

  <div>
    <!-- Item Details -->
    <div class="card" style="margin-bottom:20px;">
      <div class="card-header">
        <h2 class="card-title"><?= htmlspecialchars($item['item_name']) ?></h2>
        <span class="badge badge-<?= $item['status'] ?>"><?= ucfirst(str_replace('_',' ',$item['status'])) ?></span>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Reference No.</div>
          <div style="font-family:monospace;font-size:14px;"><?= htmlspecialchars($item['reference_no']) ?></div>
        </div>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Category</div>
          <div><?= htmlspecialchars($item['category']) ?></div>
        </div>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Location Found</div>
          <div><?= htmlspecialchars($item['location_found'] ?? 'Not specified') ?></div>
        </div>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Date Reported</div>
          <div><?= date('F d, Y', strtotime($item['date_reported'])) ?></div>
        </div>
        <?php if ($item['date_found']): ?>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Date Found</div>
          <div><?= date('F d, Y', strtotime($item['date_found'])) ?></div>
        </div>
        <?php endif; ?>
      </div>

      <?php if ($item['description']): ?>
      <div>
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:8px;">Description</div>
        <p style="color:var(--white-soft);line-height:1.7;font-size:14px;"><?= nl2br(htmlspecialchars($item['description'])) ?></p>
      </div>
      <?php endif; ?>

      <!-- Images -->
      <?php if (!empty($images)): ?>
      <div style="margin-top:20px;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:12px;">Images</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <?php foreach ($images as $img): ?>
          <img src="/<?= htmlspecialchars($img['image_path']) ?>" alt="Item image"
               style="width:120px;height:120px;object-fit:cover;border-radius:8px;border:1px solid var(--white-line);">
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>

    <!-- Claims -->
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">Claims (<?= count($claims) ?>)</h2>
      </div>
      <?php if (empty($claims)): ?>
      <p style="color:var(--white-dim);text-align:center;padding:20px;">No claims submitted for this item yet.</p>
      <?php else: ?>
      <?php foreach ($claims as $cl): ?>
      <div style="padding:16px;border:1px solid var(--white-line);border-radius:8px;margin-bottom:12px;">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
          <strong><?= htmlspecialchars($cl['first_name'].' '.$cl['last_name']) ?></strong>
          <span class="badge badge-<?= $cl['status'] ?>"><?= ucfirst($cl['status']) ?></span>
        </div>
        <div style="font-size:12px;color:var(--white-dim);margin-bottom:8px;"><?= htmlspecialchars($cl['email']) ?> <?= $cl['student_id'] ? '· ID: '.$cl['student_id'] : '' ?></div>
        <?php if ($cl['claim_note']): ?>
        <p style="font-size:13px;color:var(--white-soft);"><?= nl2br(htmlspecialchars($cl['claim_note'])) ?></p>
        <?php endif; ?>
        <?php if ($cl['status'] === 'pending'): ?>
        <div style="margin-top:10px;">
          <a href="/admin/claim-review.php?id=<?= $cl['id'] ?>" class="btn btn-primary btn-sm">Review Claim</a>
        </div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Reporter Info -->
  <div>
    <div class="card">
      <div class="card-header"><h2 class="card-title">Reported By</h2></div>
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <div class="user-avatar" style="width:48px;height:48px;font-size:16px;">
          <?= strtoupper(substr($item['first_name'],0,1).substr($item['last_name'],0,1)) ?>
        </div>
        <div>
          <div style="font-weight:500;"><?= htmlspecialchars($item['first_name'].' '.$item['last_name']) ?></div>
          <div style="font-size:12px;color:var(--blue-accent)"><?= htmlspecialchars($item['email']) ?></div>
          <?php if ($item['student_id']): ?>
          <div style="font-size:12px;color:var(--white-dim)">ID: <?= htmlspecialchars($item['student_id']) ?></div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Notify User -->
    <div class="card" style="margin-top:16px;">
      <div class="card-header"><h2 class="card-title" style="font-size:18px;">Send Notification</h2></div>
      <form method="POST" action="/api/notify.php">
        <input type="hidden" name="user_id" value="<?= $item['reported_by'] ?>">
        <input type="hidden" name="item_id" value="<?= $id ?>">
        <div class="field">
          <label>Message</label>
          <textarea name="message" placeholder="Write a note to the reporter..." style="min-height:80px;"></textarea>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">Send Notification</button>
      </form>
    </div>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
