<?php
// ============================================
// iAcademy Lost & Found — Admin Items
// admin/items.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();
$error = $success = '';

// ── Handle DELETE ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'delete') {
    $id = (int)($_POST['item_id'] ?? 0);
    $pdo->prepare("UPDATE items SET is_archived = 1 WHERE id = ?")->execute([$id]);
    $success = 'Item archived successfully.';
}

// ── Filters ──
$status   = $_GET['status']   ?? '';
$category = (int)($_GET['category'] ?? 0);
$search   = trim($_GET['q'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 15;
$offset   = ($page - 1) * $perPage;

$where = ['i.is_archived = 0'];
$params = [];

if ($status)   { $where[] = 'i.status = ?';      $params[] = $status; }
if ($category) { $where[] = 'i.category_id = ?'; $params[] = $category; }
if ($search)   { $where[] = '(i.item_name LIKE ? OR i.reference_no LIKE ? OR i.description LIKE ?)'; $params = array_merge($params, ["%$search%","%$search%","%$search%"]); }

$whereSQL = implode(' AND ', $where);

$total = (int)$pdo->prepare("SELECT COUNT(*) FROM items i WHERE $whereSQL")->execute($params) ? $pdo->prepare("SELECT COUNT(*) FROM items i WHERE $whereSQL")->execute($params) : 0;
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM items i WHERE $whereSQL");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = (int)ceil($total / $perPage);

$itemsStmt = $pdo->prepare(
    "SELECT i.*, c.name AS category, u.first_name, u.last_name,
            (SELECT image_path FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) AS primary_image
     FROM items i
     JOIN categories c ON i.category_id = c.id
     JOIN users u ON i.reported_by = u.id
     WHERE $whereSQL
     ORDER BY i.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$itemsStmt->execute($params);
$items = $itemsStmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$statuses   = ['lost','found','claimed','turned_in','disposed'];

$pageTitle = 'Manage Items';
include __DIR__ . '/../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<!-- Toolbar -->
<div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap;">
  <form method="GET" style="display:flex;gap:8px;flex:1;min-width:200px;">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search items..." style="flex:1;padding:9px 14px;background:var(--white-ghost);border:1px solid var(--white-line);border-radius:8px;color:var(--white);font-family:var(--font-body);font-size:13px;">
    <select name="status" style="padding:9px 14px;background:var(--white-ghost);border:1px solid var(--white-line);border-radius:8px;color:var(--white);font-family:var(--font-body);font-size:13px;">
      <option value="">All Statuses</option>
      <?php foreach ($statuses as $s): ?>
      <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="category" style="padding:9px 14px;background:var(--white-ghost);border:1px solid var(--white-line);border-radius:8px;color:var(--white);font-family:var(--font-body);font-size:13px;">
      <option value="">All Categories</option>
      <?php foreach ($categories as $cat): ?>
      <option value="<?= $cat['id'] ?>" <?= $category === (int)$cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-ghost">Filter</button>
  </form>
  <a href="/admin/item-add.php" class="btn btn-primary">
    <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Add Item
  </a>
</div>

<!-- Items Table -->
<div class="card">
  <div class="card-header">
    <span style="font-size:13px;color:var(--white-dim)"><?= $total ?> item<?= $total !== 1 ? 's' : '' ?> found</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Ref #</th>
          <th>Item Name</th>
          <th>Category</th>
          <th>Status</th>
          <th>Location Found</th>
          <th>Date Reported</th>
          <th>Reported By</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
        <tr>
          <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($item['reference_no']) ?></td>
          <td style="font-weight:500"><?= htmlspecialchars($item['item_name']) ?></td>
          <td style="color:var(--white-dim)"><?= htmlspecialchars($item['category']) ?></td>
          <td><span class="badge badge-<?= $item['status'] ?>"><?= ucfirst(str_replace('_',' ',$item['status'])) ?></span></td>
          <td style="color:var(--white-dim);font-size:12px"><?= htmlspecialchars($item['location_found'] ?? '—') ?></td>
          <td style="color:var(--white-dim);font-size:12px"><?= date('M d, Y', strtotime($item['date_reported'])) ?></td>
          <td style="font-size:12px"><?= htmlspecialchars($item['first_name'].' '.$item['last_name']) ?></td>
          <td>
            <div style="display:flex;gap:6px;">
              <a href="/admin/item-view.php?id=<?= $item['id'] ?>" class="btn btn-ghost btn-sm">View</a>
              <a href="/admin/item-edit.php?id=<?= $item['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
              <form method="POST" onsubmit="return confirm('Archive this item?')">
                <input type="hidden" name="_action" value="delete">
                <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm">Archive</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($items)): ?>
        <tr><td colspan="8" style="text-align:center;color:var(--white-dim);padding:40px">No items match your filters.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($pages > 1): ?>
  <div class="pagination" style="padding:16px;">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
    <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status) ?>&category=<?= $category ?>"
       class="page-btn <?= $i === $page ? 'current' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
