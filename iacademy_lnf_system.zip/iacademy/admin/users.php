<?php
// ============================================
// iAcademy Lost & Found — Admin Users
// admin/users.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo    = getPDO();
$admin  = currentUser();
$error = $success = '';

// Toggle active
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid    = (int)($_POST['user_id'] ?? 0);
    $action = $_POST['_action'] ?? '';

    if ($uid && $uid !== $admin['id']) {
        if ($action === 'toggle_active') {
            $current = (int)$pdo->prepare("SELECT is_active FROM users WHERE id=?")->execute([$uid]) ?
                       $pdo->prepare("SELECT is_active FROM users WHERE id=?")->execute([$uid]) : 1;
            $cur = $pdo->prepare("SELECT is_active FROM users WHERE id=?");
            $cur->execute([$uid]);
            $cur = (int)$cur->fetchColumn();
            $pdo->prepare("UPDATE users SET is_active=? WHERE id=?")->execute([$cur ? 0 : 1, $uid]);
            $success = 'User status updated.';
        }
    }
}

$search = trim($_GET['q'] ?? '');
$where  = $search ? "WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR student_id LIKE ?)" : "WHERE 1";
$params = $search ? ["%$search%","%$search%","%$search%","%$search%"] : [];

$usersStmt = $pdo->prepare(
    "SELECT u.*,
            (SELECT COUNT(*) FROM claims WHERE claimant_id = u.id) AS total_claims,
            (SELECT COUNT(*) FROM items WHERE reported_by = u.id) AS total_items
     FROM users u $where
     ORDER BY u.created_at DESC"
);
$usersStmt->execute($params);
$users = $usersStmt->fetchAll();

$pageTitle = 'Users';
include __DIR__ . '/../includes/header.php';
?>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div style="display:flex;gap:12px;margin-bottom:20px;align-items:center;">
  <form method="GET" style="display:flex;gap:8px;flex:1;">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search by name, email, or student ID..."
           style="flex:1;padding:9px 14px;background:var(--white-ghost);border:1px solid var(--white-line);border-radius:8px;color:var(--white);font-family:var(--font-body);font-size:13px;">
    <button type="submit" class="btn btn-ghost">Search</button>
    <?php if ($search): ?><a href="/admin/users.php" class="btn btn-ghost">Clear</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Student ID</th>
          <th>Role</th>
          <th>Claims</th>
          <th>Items</th>
          <th>Status</th>
          <th>Joined</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <div class="user-avatar" style="width:30px;height:30px;font-size:11px;">
                <?= strtoupper(substr($u['first_name'],0,1).substr($u['last_name'],0,1)) ?>
              </div>
              <?= htmlspecialchars($u['first_name'].' '.$u['last_name']) ?>
            </div>
          </td>
          <td style="font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($u['email']) ?></td>
          <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($u['student_id'] ?? '—') ?></td>
          <td>
            <span class="badge <?= $u['role'] === 'admin' ? 'badge-found' : 'badge-claimed' ?>"><?= ucfirst($u['role']) ?></span>
          </td>
          <td style="text-align:center"><?= $u['total_claims'] ?></td>
          <td style="text-align:center"><?= $u['total_items'] ?></td>
          <td>
            <span class="badge <?= $u['is_active'] ? 'badge-found' : 'badge-rejected' ?>">
              <?= $u['is_active'] ? 'Active' : 'Inactive' ?>
            </span>
          </td>
          <td style="font-size:12px;color:var(--white-dim)"><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
          <td>
            <?php if ($u['id'] !== $admin['id']): ?>
            <form method="POST" style="display:inline">
              <input type="hidden" name="_action" value="toggle_active">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <button type="submit" class="btn <?= $u['is_active'] ? 'btn-danger' : 'btn-ghost' ?> btn-sm"
                      onclick="return confirm('Change this user\'s status?')">
                <?= $u['is_active'] ? 'Deactivate' : 'Activate' ?>
              </button>
            </form>
            <?php else: ?>
            <span style="font-size:11px;color:var(--white-dim)">You</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($users)): ?>
        <tr><td colspan="9" style="text-align:center;color:var(--white-dim);padding:40px">No users found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
