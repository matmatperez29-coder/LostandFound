<?php
// ============================================
// iAcademy Lost & Found — Shared Header
// includes/header.php
// ============================================
// Usage: include this at the top of any page
// after calling requireLogin().
// Expects $pageTitle variable to be set.
// ============================================

if (!isset($pageTitle)) $pageTitle = 'iAcademy Lost & Found';
$user = currentUser();
$isAdmin = $user['role'] === 'admin';

// Active page helper
function isActive(string $segment): string {
    return str_contains($_SERVER['SCRIPT_NAME'], $segment) ? 'active' : '';
}

// Unread notifications count
$unreadCount = 0;
try {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $stmt->execute([$user['id']]);
    $unreadCount = (int)$stmt->fetchColumn();
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?= htmlspecialchars($pageTitle) ?> — iAcademy L&F</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
  <style>
    :root {
      --navy-deep:   #05063a;
      --navy-mid:    #0a0e6b;
      --navy-bright: #1a24c8;
      --blue-glow:   #2b5ce6;
      --blue-accent: #4d82ff;
      --white:       #ffffff;
      --white-soft:  rgba(255,255,255,0.85);
      --white-dim:   rgba(255,255,255,0.45);
      --white-ghost: rgba(255,255,255,0.08);
      --white-line:  rgba(255,255,255,0.12);
      --error:       #ff6b6b;
      --success:     #6bffb8;
      --warning:     #ffa94d;
      --info:        #74c0fc;
      --font-display: 'Cormorant Garamond', serif;
      --font-body:    'DM Sans', sans-serif;
      --sidebar-w:   240px;
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html, body {
      font-family: var(--font-body);
      background: var(--navy-deep);
      color: var(--white);
      min-height: 100vh;
    }

    /* ── App Shell ── */
    .app-shell {
      display: grid;
      grid-template-columns: var(--sidebar-w) 1fr;
      grid-template-rows: auto 1fr;
      min-height: 100vh;
    }

    /* ── Sidebar ── */
    .sidebar {
      grid-row: 1 / -1;
      background: rgba(10,14,107,0.4);
      border-right: 1px solid var(--white-line);
      display: flex; flex-direction: column;
      padding: 0;
      position: sticky; top: 0; height: 100vh;
      overflow-y: auto;
      backdrop-filter: blur(20px);
    }

    .sidebar-logo {
      padding: 24px 24px 20px;
      border-bottom: 1px solid var(--white-line);
      display: flex; align-items: center; gap: 12px;
    }

    .sidebar-logo svg { width: 36px; height: auto; flex-shrink: 0; }

    .sidebar-logo-text {
      display: flex; flex-direction: column;
    }
    .sidebar-logo-text strong {
      font-family: var(--font-display);
      font-size: 18px; font-weight: 600;
      line-height: 1.1;
    }
    .sidebar-logo-text span {
      font-size: 10px; letter-spacing: 0.15em; text-transform: uppercase;
      color: var(--blue-accent); font-weight: 500;
    }

    .sidebar-section {
      padding: 20px 12px 8px;
    }

    .sidebar-section-label {
      font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase;
      color: var(--white-dim); font-weight: 500;
      padding: 0 12px; margin-bottom: 8px;
    }

    .nav-item {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px; border-radius: 8px;
      font-size: 13.5px; font-weight: 400;
      color: var(--white-dim);
      text-decoration: none;
      transition: all 0.15s ease;
      margin-bottom: 2px;
      position: relative;
    }

    .nav-item:hover {
      background: var(--white-ghost);
      color: var(--white);
    }

    .nav-item.active {
      background: rgba(77,130,255,0.15);
      color: var(--blue-accent);
      font-weight: 500;
    }

    .nav-item.active::before {
      content: '';
      position: absolute; left: 0; top: 20%; bottom: 20%;
      width: 3px; border-radius: 2px;
      background: var(--blue-accent);
    }

    .nav-icon {
      width: 18px; height: 18px; flex-shrink: 0;
      opacity: 0.7;
    }
    .nav-item.active .nav-icon { opacity: 1; }

    .nav-badge {
      margin-left: auto;
      background: var(--blue-accent);
      color: var(--navy-deep);
      font-size: 10px; font-weight: 700;
      padding: 1px 6px; border-radius: 10px;
      min-width: 18px; text-align: center;
    }

    .sidebar-footer {
      margin-top: auto;
      padding: 16px 12px;
      border-top: 1px solid var(--white-line);
    }

    .user-info {
      display: flex; align-items: center; gap: 10px;
      padding: 8px 12px; border-radius: 8px;
      background: var(--white-ghost);
      margin-bottom: 8px;
    }

    .user-avatar {
      width: 32px; height: 32px; border-radius: 50%;
      background: linear-gradient(135deg, var(--navy-bright), var(--blue-accent));
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 600; flex-shrink: 0;
      color: white;
    }

    .user-name {
      font-size: 12.5px; font-weight: 500;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      max-width: 130px;
    }
    .user-role {
      font-size: 10px; color: var(--blue-accent);
      text-transform: capitalize; letter-spacing: 0.05em;
    }

    .logout-btn {
      display: flex; align-items: center; gap: 8px;
      padding: 8px 12px; border-radius: 8px;
      font-size: 12.5px; color: var(--white-dim);
      text-decoration: none;
      transition: all 0.15s;
    }
    .logout-btn:hover { background: rgba(255,107,107,0.1); color: var(--error); }

    /* ── Top Bar ── */
    .topbar {
      background: rgba(5,6,58,0.8);
      border-bottom: 1px solid var(--white-line);
      padding: 16px 32px;
      display: flex; align-items: center; gap: 16px;
      backdrop-filter: blur(20px);
      position: sticky; top: 0; z-index: 100;
    }

    .topbar-title {
      font-family: var(--font-display);
      font-size: 24px; font-weight: 300;
      flex: 1;
    }

    .topbar-actions {
      display: flex; align-items: center; gap: 12px;
    }

    .notif-btn {
      position: relative;
      width: 38px; height: 38px; border-radius: 8px;
      background: var(--white-ghost);
      border: 1px solid var(--white-line);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; text-decoration: none;
      color: var(--white-dim);
      transition: all 0.15s;
    }
    .notif-btn:hover { background: rgba(77,130,255,0.15); color: var(--blue-accent); }

    .notif-dot {
      position: absolute; top: 6px; right: 6px;
      width: 8px; height: 8px; border-radius: 50%;
      background: var(--blue-accent);
      border: 2px solid var(--navy-deep);
    }

    /* ── Main Content ── */
    .main-content {
      padding: 32px;
      overflow-x: hidden;
    }

    /* ── Cards ── */
    .card {
      background: rgba(255,255,255,0.04);
      border: 1px solid var(--white-line);
      border-radius: 12px;
      padding: 24px;
    }

    .card-header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 20px;
    }

    .card-title {
      font-family: var(--font-display);
      font-size: 22px; font-weight: 300;
    }

    /* ── Status Badges ── */
    .badge {
      display: inline-flex; align-items: center;
      padding: 3px 10px; border-radius: 20px;
      font-size: 11px; font-weight: 500;
      text-transform: uppercase; letter-spacing: 0.05em;
    }
    .badge-lost     { background: rgba(255,107,107,0.15); color: #ff6b6b; }
    .badge-found    { background: rgba(107,255,184,0.15); color: #6bffb8; }
    .badge-claimed  { background: rgba(77,130,255,0.15);  color: #4d82ff; }
    .badge-turned_in { background: rgba(116,192,252,0.15); color: #74c0fc; }
    .badge-disposed  { background: rgba(255,255,255,0.08); color: var(--white-dim); }
    .badge-pending  { background: rgba(255,169,77,0.15);  color: #ffa94d; }
    .badge-approved { background: rgba(107,255,184,0.15); color: #6bffb8; }
    .badge-rejected { background: rgba(255,107,107,0.15); color: #ff6b6b; }

    /* ── Buttons ── */
    .btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 9px 18px; border-radius: 8px;
      font-family: var(--font-body); font-size: 13px; font-weight: 500;
      cursor: pointer; text-decoration: none;
      transition: all 0.15s; border: none; outline: none;
    }
    .btn-primary {
      background: var(--blue-accent);
      color: var(--navy-deep);
    }
    .btn-primary:hover { background: #6b9fff; }

    .btn-ghost {
      background: var(--white-ghost);
      border: 1px solid var(--white-line);
      color: var(--white-dim);
    }
    .btn-ghost:hover { background: rgba(255,255,255,0.12); color: var(--white); }

    .btn-danger {
      background: rgba(255,107,107,0.15);
      border: 1px solid rgba(255,107,107,0.3);
      color: var(--error);
    }
    .btn-danger:hover { background: rgba(255,107,107,0.25); }

    .btn-sm { padding: 6px 12px; font-size: 12px; }

    /* ── Alerts ── */
    .alert {
      display: flex; align-items: center; gap: 10px;
      padding: 12px 16px; border-radius: 8px;
      font-size: 13.5px; margin-bottom: 16px;
    }
    .alert-error   { background: rgba(255,107,107,0.1); border: 1px solid rgba(255,107,107,0.25); color: var(--error); }
    .alert-success { background: rgba(107,255,184,0.1); border: 1px solid rgba(107,255,184,0.25); color: var(--success); }
    .alert-info    { background: rgba(116,192,252,0.1); border: 1px solid rgba(116,192,252,0.25); color: var(--info); }
    .alert-warning { background: rgba(255,169,77,0.1);  border: 1px solid rgba(255,169,77,0.25);  color: var(--warning); }

    /* ── Table ── */
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
    th {
      text-align: left; padding: 10px 16px;
      font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase;
      color: var(--white-dim); font-weight: 500;
      border-bottom: 1px solid var(--white-line);
    }
    td {
      padding: 12px 16px;
      border-bottom: 1px solid rgba(255,255,255,0.05);
      vertical-align: middle;
    }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: var(--white-ghost); }

    /* ── Form Fields ── */
    .field { margin-bottom: 16px; }
    .field label {
      display: block; font-size: 12px; font-weight: 500;
      letter-spacing: 0.05em; text-transform: uppercase;
      color: var(--white-dim); margin-bottom: 8px;
    }
    .field input,
    .field select,
    .field textarea {
      width: 100%; padding: 10px 14px;
      background: var(--white-ghost);
      border: 1px solid var(--white-line);
      border-radius: 8px;
      font-family: var(--font-body); font-size: 13.5px;
      color: var(--white);
      outline: none; transition: border-color 0.15s;
    }
    .field input:focus,
    .field select:focus,
    .field textarea:focus {
      border-color: var(--blue-accent);
    }
    .field input::placeholder,
    .field textarea::placeholder { color: var(--white-dim); }
    .field select option { background: var(--navy-deep); }
    .field textarea { resize: vertical; min-height: 90px; }

    /* ── Grid utils ── */
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
    .grid-4 { display: grid; grid-template-columns: repeat(4,1fr); gap: 20px; }

    /* ── Stat cards ── */
    .stat-card {
      background: rgba(255,255,255,0.04);
      border: 1px solid var(--white-line);
      border-radius: 12px; padding: 20px 24px;
    }
    .stat-label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.15em; color: var(--white-dim); margin-bottom: 8px; }
    .stat-value { font-family: var(--font-display); font-size: 40px; font-weight: 300; line-height: 1; }
    .stat-sub   { font-size: 12px; color: var(--white-dim); margin-top: 4px; }

    /* ── Pagination ── */
    .pagination {
      display: flex; align-items: center; gap: 6px;
      margin-top: 20px;
    }
    .page-btn {
      padding: 6px 12px; border-radius: 6px;
      font-size: 13px;
      background: var(--white-ghost);
      border: 1px solid var(--white-line);
      color: var(--white-dim);
      text-decoration: none;
      transition: all 0.15s;
    }
    .page-btn:hover { background: rgba(77,130,255,0.15); color: var(--blue-accent); }
    .page-btn.current { background: rgba(77,130,255,0.2); color: var(--blue-accent); border-color: var(--blue-accent); font-weight: 600; }

    /* ── Background ── */
    .bg-canvas {
      position: fixed; inset: 0; z-index: -1;
      background:
        radial-gradient(ellipse 80% 60% at 20% 80%, rgba(26,36,200,0.35) 0%, transparent 60%),
        radial-gradient(ellipse 60% 50% at 80% 20%, rgba(43,92,230,0.2) 0%, transparent 55%),
        var(--navy-deep);
    }

    /* ── Responsive ── */
    @media (max-width: 900px) {
      .app-shell { grid-template-columns: 1fr; }
      .sidebar { display: none; }
      .grid-4 { grid-template-columns: repeat(2,1fr); }
      .grid-3 { grid-template-columns: 1fr 1fr; }
    }
  </style>
</head>
<body>
<div class="bg-canvas"></div>
<div class="app-shell">

  <!-- ── Sidebar ── -->
  <nav class="sidebar">
    <div class="sidebar-logo">
      <svg viewBox="0 0 120 138" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M60 4L112 32V88L60 116L8 88V32L60 4Z" fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.25)" stroke-width="1.5"/>
        <rect x="54" y="38" width="12" height="10" rx="2" fill="white" opacity="0.9"/>
        <path d="M60 54 L60 88" stroke="white" stroke-width="5" stroke-linecap="round"/>
        <path d="M42 88 L60 54 L78 88" stroke="white" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        <path d="M50 76 L70 76" stroke="white" stroke-width="4" stroke-linecap="round"/>
      </svg>
      <div class="sidebar-logo-text">
        <strong>Lost &amp; Found</strong>
        <span>iAcademy</span>
      </div>
    </div>

    <?php if ($isAdmin): ?>
    <div class="sidebar-section">
      <div class="sidebar-section-label">Admin</div>
      <a href="/admin/dashboard.php" class="nav-item <?= isActive('admin/dashboard') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Dashboard
      </a>
      <a href="/admin/items.php" class="nav-item <?= isActive('admin/items') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
        Manage Items
      </a>
      <a href="/admin/claims.php" class="nav-item <?= isActive('admin/claims') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        Claims
      </a>
      <a href="/admin/users.php" class="nav-item <?= isActive('admin/users') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        Users
      </a>
      <a href="/admin/activity.php" class="nav-item <?= isActive('admin/activity') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
        Activity Log
      </a>
    </div>
    <?php else: ?>
    <div class="sidebar-section">
      <div class="sidebar-section-label">Menu</div>
      <a href="/user/dashboard.php" class="nav-item <?= isActive('user/dashboard') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Dashboard
      </a>
      <a href="/user/items.php" class="nav-item <?= isActive('user/items') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Browse Items
      </a>
      <a href="/user/my-claims.php" class="nav-item <?= isActive('user/my-claims') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
        My Claims
      </a>
      <a href="/user/notifications.php" class="nav-item <?= isActive('user/notifications') ?>">
        <svg class="nav-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        Notifications
        <?php if ($unreadCount > 0): ?>
        <span class="nav-badge"><?= $unreadCount ?></span>
        <?php endif; ?>
      </a>
    </div>
    <?php endif; ?>

    <div class="sidebar-footer">
      <div class="user-info">
        <div class="user-avatar"><?= strtoupper(substr($user['first_name'],0,1) . substr($user['last_name'],0,1)) ?></div>
        <div>
          <div class="user-name"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></div>
          <div class="user-role"><?= htmlspecialchars($user['role']) ?></div>
        </div>
      </div>
      <a href="/auth/logout.php" class="logout-btn">
        <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Sign Out
      </a>
    </div>
  </nav>

  <!-- ── Top Bar + Main Content wrapper ── -->
  <div style="display:flex; flex-direction:column; min-height:100vh; overflow:hidden;">
    <header class="topbar">
      <h1 class="topbar-title"><?= htmlspecialchars($pageTitle) ?></h1>
      <div class="topbar-actions">
        <a href="<?= $isAdmin ? '/admin/notifications.php' : '/user/notifications.php' ?>" class="notif-btn" title="Notifications">
          <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
          <?php if ($unreadCount > 0): ?><span class="notif-dot"></span><?php endif; ?>
        </a>
      </div>
    </header>
    <main class="main-content">
