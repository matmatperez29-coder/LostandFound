# iAcademy Lost & Found System

A full PHP/MySQL lost and found management system for iAcademy.

---

## Quick Setup

### 1. Database
```bash
mysql -u root -p < iacademy_lnf.sql
```
This creates the `iacademy_lnf` database, all tables, 8 item categories, and a default admin account.

### 2. Configure DB Connection
Edit `config/db.php` and update your credentials:
```php
define('DB_USER', 'root');   // your MySQL username
define('DB_PASS', '');       // your MySQL password
```

### 3. Place Files
Copy the entire folder into your web server root (e.g. `htdocs/iacademy/` for XAMPP).

### 4. Set Upload Permissions
```bash
chmod 755 uploads/items uploads/proofs
```

### 5. Open in Browser
```
http://localhost/iacademy/
```

---

## Default Login

| Field    | Value                       |
|----------|-----------------------------|
| Email    | admin@iacademy.edu.ph       |
| Password | password                    |
| Role     | Admin                       |

> **Change this password immediately after first login.**

---

## File Structure

```
iacademy/
├── index.php                  ← Root redirect
├── .htaccess                  ← Security rules
├── iacademy_lnf.sql           ← Database setup
│
├── auth/
│   ├── login.php              ← Login page
│   ├── register.php           ← Registration page
│   └── logout.php             ← Logout handler
│
├── config/
│   ├── db.php                 ← PDO database connection
│   └── auth.php               ← Session/auth guards
│
├── includes/
│   ├── header.php             ← Shared sidebar + topbar
│   └── footer.php             ← Closes HTML shell
│
├── admin/
│   ├── dashboard.php          ← Admin overview & stats
│   ├── items.php              ← Browse/filter all items
│   ├── item-add.php           ← Add new found item
│   ├── item-edit.php          ← Edit item details
│   ├── item-view.php          ← Full item detail + claims
│   ├── claims.php             ← All claims list
│   ├── claim-review.php       ← Approve / reject a claim
│   ├── users.php              ← Manage user accounts
│   ├── activity.php           ← Activity log
│   └── notifications.php      ← Admin notifications
│
├── user/
│   ├── dashboard.php          ← Member overview
│   ├── items.php              ← Browse found items (limited view)
│   ├── item-view.php          ← Item detail + claim form
│   ├── my-claims.php          ← User's submitted claims
│   └── notifications.php      ← User notifications
│
├── api/
│   ├── notify.php             ← Send notification to user
│   └── delete-image.php       ← Remove item image
│
└── uploads/
    ├── items/                 ← Item photos
    └── proofs/                ← Claim proof uploads
```

---

## Flowchart Coverage

| Flowchart Step              | Implemented In                            |
|-----------------------------|-------------------------------------------|
| Login & Authentication      | `auth/login.php` + `config/auth.php`      |
| Register                    | `auth/register.php`                       |
| Member: View/Search Items   | `user/items.php`                          |
| Member: Item Detail         | `user/item-view.php`                      |
| Member: Submit Claim        | `user/item-view.php` (form)               |
| Member: My Claims           | `user/my-claims.php`                      |
| Member: Notifications       | `user/notifications.php`                  |
| Admin: Dashboard            | `admin/dashboard.php`                     |
| Admin: Post/Edit/Delete Item| `admin/item-add.php`, `item-edit.php`     |
| Admin: Review Claims        | `admin/claims.php`, `claim-review.php`    |
| Admin: Approve / Reject     | `admin/claim-review.php`                  |
| Admin: Notify Users         | `api/notify.php`                          |
| Admin: User Management      | `admin/users.php`                         |
| Admin: Activity Log         | `admin/activity.php`                      |
| Logout                      | `auth/logout.php`                         |

---

## Requirements
- PHP 8.0+
- MySQL / MariaDB 10.4+
- Apache with `mod_rewrite` (or equivalent)
- XAMPP / Laragon / any local PHP stack
