<?php
// ============================================
// iAcademy Lost & Found — User My Claims
// user/my-claims.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('user');

$pdo  = getPDO();
$user = currentUser();

$filter = $_GET['status'] ?? 'all';
$where  = $filter !== 'all' ? "AND cl.status = ?" : "";
$params = [$user['id']];
if ($filter !== 'all') $params[] = $filter;

$claimsStmt = $pdo->prepare(
    "SELECT cl.*, i.item_name, i.reference_no, i.status AS item_status, i.id AS item_id,
            c.name AS category,
            (SELECT image_path FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) AS primary_image
     FROM claims cl
     JOIN items i ON cl.item_id = i.id
     JOIN categories c ON i.category_id = c.id
     WHERE cl.claimant_id = ? $where
     ORDER BY cl.created_at DESC"
);
$claimsStmt->execute($params);
$claims = $claimsStmt->fetchAll();

$pageTitle = 'My Claims';
include __DIR__ . '/../includes/header.php';
?>

<!-- Filter Tabs -->
<div style="display:flex;gap:8px;margin-bottom:24px;">
  <?php foreach (['all'=>'All','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $val=>$label): ?>
  <a href="?status=<?= $val ?>" class="btn <?= $filter === $val ? 'btn-primary' : 'btn-ghost' ?> btn-sm"><?= $label ?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($claims)): ?>
<div style="text-align:center;padding:80px 20px;color:var(--white-dim);">
  <div style="font-size:48px;margin-bottom:16px;">📋</div>
  <div style="font-size:16px;margin-bottom:8px;">No <?= $filter !== 'all' ? $filter : '' ?> claims yet.</div>
  <a href="/user/items.php" class="btn btn-primary" style="margin-top:12px;">Browse Found Items</a>
</div>
<?php else: ?>

<div style="display:flex;flex-direction:column;gap:14px;">
  <?php foreach ($claims as $cl): ?>
  <div style="background:rgba(255,255,255,0.04);border:1px solid var(--white-line);border-radius:12px;padding:20px;display:flex;gap:20px;align-items:flex-start;">

    <!-- Image -->
    <div style="flex-shrink:0;">
      <?php if ($cl['primary_image']): ?>
      <img src="/<?= htmlspecialchars($cl['primary_image']) ?>" alt="" style="width:80px;height:80px;object-fit:cover;border-radius:8px;border:1px solid var(--white-line);">
      <?php else: ?>
      <div style="width:80px;height:80px;background:rgba(77,130,255,0.1);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;">📦</div>
      <?php endif; ?>
    </div>

    <!-- Details -->
    <div style="flex:1;min-width:0;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
        <div>
          <a href="/user/item-view.php?id=<?= $cl['item_id'] ?>" style="font-weight:500;font-size:15px;text-decoration:none;color:var(--white);"><?= htmlspecialchars($cl['item_name']) ?></a>
          <div style="font-size:11px;color:var(--blue-accent);text-transform:uppercase;letter-spacing:.1em;margin-top:2px;"><?= htmlspecialchars($cl['category']) ?></div>
        </div>
        <span class="badge badge-<?= $cl['status'] ?>"><?= ucfirst($cl['status']) ?></span>
      </div>

      <div style="display:flex;gap:20px;font-size:12px;color:var(--white-dim);margin-bottom:10px;flex-wrap:wrap;">
        <span>Ref: <span style="font-family:monospace"><?= htmlspecialchars($cl['reference_no']) ?></span></span>
        <span>Submitted: <?= date('M d, Y', strtotime($cl['created_at'])) ?></span>
        <?php if ($cl['reviewed_at']): ?>
        <span>Reviewed: <?= date('M d, Y', strtotime($cl['reviewed_at'])) ?></span>
        <?php endif; ?>
      </div>

      <?php if ($cl['claim_note']): ?>
      <p style="font-size:13px;color:var(--white-dim);margin-bottom:10px;line-height:1.5;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;">
        <?= htmlspecialchars($cl['claim_note']) ?>
      </p>
      <?php endif; ?>

      <?php if ($cl['admin_note']): ?>
      <div style="padding:10px 14px;background:rgba(77,130,255,0.08);border:1px solid rgba(77,130,255,0.15);border-radius:6px;font-size:13px;color:var(--white-soft);">
        <span style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--blue-accent);display:block;margin-bottom:4px;">Admin Note</span>
        <?= htmlspecialchars($cl['admin_note']) ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Status icon -->
    <div style="flex-shrink:0;font-size:28px;">
      <?= $cl['status'] === 'approved' ? '✅' : ($cl['status'] === 'rejected' ? '❌' : '⏳') ?>
    </div>

  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
