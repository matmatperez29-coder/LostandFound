<?php
// ============================================
// iAcademy Lost & Found — User Item View
// user/item-view.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('user');

$pdo  = getPDO();
$user = currentUser();
$id   = (int)($_GET['id'] ?? 0);
$error = $success = '';

// Load item — limited details for member view (per flowchart)
$itemStmt = $pdo->prepare(
    "SELECT i.id, i.item_name, i.reference_no, i.status, i.location_found,
            i.date_reported, i.date_found, i.description, i.category_id,
            c.name AS category
     FROM items i
     JOIN categories c ON i.category_id = c.id
     WHERE i.id = ? AND i.is_archived = 0"
);
$itemStmt->execute([$id]);
$item = $itemStmt->fetch();

if (!$item) { header('Location: /user/items.php'); exit; }

$images = $pdo->prepare("SELECT * FROM item_images WHERE item_id = ? ORDER BY is_primary DESC");
$images->execute([$id]);
$images = $images->fetchAll();

// Check if user already has a pending/approved claim
$existingClaim = $pdo->prepare("SELECT id, status FROM claims WHERE item_id = ? AND claimant_id = ? LIMIT 1");
$existingClaim->execute([$id, $user['id']]);
$existingClaim = $existingClaim->fetch();

// Handle Claim Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$existingClaim) {
    $claim_note  = trim($_POST['claim_note'] ?? '');
    $proof_path  = null;

    // Handle proof upload
    if (!empty($_FILES['proof']['tmp_name'])) {
        $uploadDir = __DIR__ . '/../uploads/proofs/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $ext  = pathinfo($_FILES['proof']['name'], PATHINFO_EXTENSION);
        $fname = $user['id'] . '_' . $id . '_' . time() . '.' . strtolower($ext);
        if (move_uploaded_file($_FILES['proof']['tmp_name'], $uploadDir . $fname)) {
            $proof_path = 'uploads/proofs/' . $fname;
        }
    }

    $pdo->prepare(
        "INSERT INTO claims (item_id, claimant_id, proof_path, claim_note) VALUES (?,?,?,?)"
    )->execute([$id, $user['id'], $proof_path, $claim_note ?: null]);

    $claimId = $pdo->lastInsertId();

    // Notify user
    $pdo->prepare(
        "INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)"
    )->execute([$user['id'], 'Claim Submitted', "Your claim for \"{$item['item_name']}\" is under review.", 'info', '/user/my-claims.php']);

    // Log
    $pdo->prepare("INSERT INTO activity_log (actor_id, action, target_type, target_id, ip_address) VALUES (?,?,?,?,?)")
        ->execute([$user['id'], 'claim.create', 'claim', $claimId, $_SERVER['REMOTE_ADDR'] ?? null]);

    $success = 'Claim submitted! You will receive a notification when it has been reviewed.';
    $existingClaim = ['id' => $claimId, 'status' => 'pending'];
}

$pageTitle = htmlspecialchars($item['item_name']);
include __DIR__ . '/../includes/header.php';
?>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:flex;gap:8px;margin-bottom:20px;">
  <a href="/user/items.php" class="btn btn-ghost btn-sm">← Browse Items</a>
</div>

<div style="display:grid;grid-template-columns:1fr 380px;gap:24px;">

  <!-- Item Details -->
  <div>
    <div class="card" style="margin-bottom:20px;">
      <!-- Images -->
      <?php if (!empty($images)): ?>
      <div style="margin-bottom:20px;">
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <?php foreach ($images as $idx => $img): ?>
          <img src="/<?= htmlspecialchars($img['image_path']) ?>" alt=""
               style="<?= $idx === 0 ? 'width:100%;height:260px;' : 'width:80px;height:80px;' ?>object-fit:cover;border-radius:8px;border:1px solid var(--white-line);">
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
        <div>
          <div style="font-size:11px;color:var(--blue-accent);text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px;"><?= htmlspecialchars($item['category']) ?></div>
          <h2 style="font-family:var(--font-display);font-size:32px;font-weight:300;line-height:1.2;"><?= htmlspecialchars($item['item_name']) ?></h2>
        </div>
        <span class="badge badge-<?= $item['status'] ?>"><?= ucfirst(str_replace('_',' ',$item['status'])) ?></span>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Reference No.</div>
          <div style="font-family:monospace;"><?= htmlspecialchars($item['reference_no']) ?></div>
        </div>
        <?php if ($item['location_found']): ?>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Location Found</div>
          <div><?= htmlspecialchars($item['location_found']) ?></div>
        </div>
        <?php endif; ?>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Date Reported</div>
          <div><?= date('F d, Y', strtotime($item['date_reported'])) ?></div>
        </div>
      </div>

      <?php if ($item['description']): ?>
      <div>
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:8px;">Description</div>
        <p style="color:var(--white-soft);line-height:1.7;font-size:14px;"><?= nl2br(htmlspecialchars($item['description'])) ?></p>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Claim Panel -->
  <div>
    <div class="card">
      <?php if ($existingClaim): ?>
        <div style="text-align:center;padding:20px 0;">
          <div style="font-size:36px;margin-bottom:12px">
            <?= $existingClaim['status'] === 'approved' ? '✅' : ($existingClaim['status'] === 'rejected' ? '❌' : '⏳') ?>
          </div>
          <div style="font-weight:500;margin-bottom:8px;">
            <?= $existingClaim['status'] === 'approved' ? 'Claim Approved!' : ($existingClaim['status'] === 'rejected' ? 'Claim Rejected' : 'Claim Pending Review') ?>
          </div>
          <div style="font-size:13px;color:var(--white-dim);line-height:1.6;">
            <?php if ($existingClaim['status'] === 'pending'): ?>
              Your claim has been submitted and is awaiting admin review.
            <?php elseif ($existingClaim['status'] === 'approved'): ?>
              Congratulations! Please coordinate with the admin for item pickup.
            <?php else: ?>
              Unfortunately your claim was not approved. Contact the admin for more information.
            <?php endif; ?>
          </div>
          <a href="/user/my-claims.php" class="btn btn-ghost btn-sm" style="margin-top:16px;">View My Claims</a>
        </div>

      <?php elseif (in_array($item['status'], ['claimed','disposed'])): ?>
        <div style="text-align:center;padding:20px 0;color:var(--white-dim);">
          <div style="font-size:36px;margin-bottom:12px">📦</div>
          <div>This item is no longer available for claiming.</div>
        </div>

      <?php else: ?>
        <h2 class="card-title" style="margin-bottom:16px;">Claim This Item</h2>
        <p style="font-size:13px;color:var(--white-dim);margin-bottom:20px;line-height:1.6;">
          Fill out the form below to submit a claim. The admin will review your submission and get back to you.
        </p>

        <form method="POST" enctype="multipart/form-data">
          <div class="field">
            <label>Your Note / Description</label>
            <textarea name="claim_note" placeholder="Describe why this is your item. Include details like where you lost it, when, and any distinguishing features you remember..." style="min-height:120px;"></textarea>
          </div>

          <div class="field">
            <label>Proof of Ownership (optional)</label>
            <input type="file" name="proof" accept="image/*,.pdf" style="padding:10px;">
            <div style="font-size:11px;color:var(--white-dim);margin-top:4px;">Photo, screenshot, or PDF — anything that proves ownership.</div>
          </div>

          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;"
                  onclick="return confirm('Submit this claim?')">
            Submit Claim
          </button>
        </form>
      <?php endif; ?>
    </div>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
