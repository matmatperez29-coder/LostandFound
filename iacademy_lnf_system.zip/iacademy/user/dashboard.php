<?php
// ============================================
// iAcademy Lost & Found — User Dashboard
// user/dashboard.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('user');

$pdo  = getPDO();
$user = currentUser();

// User's stats
$myClaims   = (int)$pdo->prepare("SELECT COUNT(*) FROM claims WHERE claimant_id = ?")->execute([$user['id']]) ? 0 : 0;
$myClaimsStmt = $pdo->prepare("SELECT COUNT(*) FROM claims WHERE claimant_id = ?"); $myClaimsStmt->execute([$user['id']]); $myClaims = (int)$myClaimsStmt->fetchColumn();
$approvedStmt = $pdo->prepare("SELECT COUNT(*) FROM claims WHERE claimant_id = ? AND status = 'approved'"); $approvedStmt->execute([$user['id']]); $myApproved = (int)$approvedStmt->fetchColumn();
$unreadStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0"); $unreadStmt->execute([$user['id']]); $unread = (int)$unreadStmt->fetchColumn();

// Total available found items
$foundItems = (int)$pdo->query("SELECT COUNT(*) FROM items WHERE status = 'found' AND is_archived = 0")->fetchColumn();

// Recent found items (for the member browse view — limited details per flowchart)
$recentFound = $pdo->query(
    "SELECT i.id, i.item_name, i.reference_no, i.date_reported, i.status, i.location_found,
            c.name AS category,
            (SELECT image_path FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) AS primary_image
     FROM items i
     JOIN categories c ON i.category_id = c.id
     WHERE i.status IN ('found','turned_in') AND i.is_archived = 0
     ORDER BY i.created_at DESC LIMIT 6"
)->fetchAll();

// My recent claims
$myRecentClaims = $pdo->prepare(
    "SELECT cl.*, i.item_name, i.reference_no
     FROM claims cl JOIN items i ON cl.item_id = i.id
     WHERE cl.claimant_id = ?
     ORDER BY cl.created_at DESC LIMIT 4"
);
$myRecentClaims->execute([$user['id']]);
$myRecentClaims = $myRecentClaims->fetchAll();

// Recent notifications
$notifs = $pdo->prepare(
    "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 4"
);
$notifs->execute([$user['id']]);
$notifs = $notifs->fetchAll();

$pageTitle = 'Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<div style="margin-bottom:28px;">
  <h2 style="font-family:var(--font-display);font-size:28px;font-weight:300;margin-bottom:4px;">
    Welcome back, <?= htmlspecialchars($user['first_name']) ?> 👋
  </h2>
  <p style="color:var(--white-dim);font-size:14px;">Find your lost items or check the status of your claims.</p>
</div>

<!-- Stats -->
<div class="grid-4" style="margin-bottom:28px;">
  <div class="stat-card">
    <div class="stat-label">Found Items</div>
    <div class="stat-value" style="color:var(--success)"><?= $foundItems ?></div>
    <div class="stat-sub">Available to claim</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">My Claims</div>
    <div class="stat-value"><?= $myClaims ?></div>
    <div class="stat-sub">Total submitted</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Approved</div>
    <div class="stat-value" style="color:var(--blue-accent)"><?= $myApproved ?></div>
    <div class="stat-sub">Claims approved</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Notifications</div>
    <div class="stat-value" style="color:var(--warning)"><?= $unread ?></div>
    <div class="stat-sub">Unread</div>
  </div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">

  <div>
    <!-- Recent Found Items -->
    <div class="card" style="margin-bottom:20px;">
      <div class="card-header">
        <h2 class="card-title">Recently Found Items</h2>
        <a href="/user/items.php" class="btn btn-ghost btn-sm">Browse All</a>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <?php foreach ($recentFound as $item): ?>
        <a href="/user/item-view.php?id=<?= $item['id'] ?>" style="text-decoration:none;">
          <div style="background:var(--white-ghost);border:1px solid var(--white-line);border-radius:10px;padding:14px;transition:all .15s;"
               onmouseover="this.style.borderColor='var(--blue-accent)'" onmouseout="this.style.borderColor='var(--white-line)'">
            <?php if ($item['primary_image']): ?>
            <img src="/<?= htmlspecialchars($item['primary_image']) ?>" alt="" style="width:100%;height:90px;object-fit:cover;border-radius:6px;margin-bottom:10px;">
            <?php else: ?>
            <div style="width:100%;height:90px;background:rgba(77,130,255,0.1);border-radius:6px;margin-bottom:10px;display:flex;align-items:center;justify-content:center;color:var(--blue-accent);">📦</div>
            <?php endif; ?>
            <div style="font-weight:500;font-size:13.5px;margin-bottom:4px;"><?= htmlspecialchars($item['item_name']) ?></div>
            <div style="font-size:11px;color:var(--white-dim);margin-bottom:6px;"><?= htmlspecialchars($item['category']) ?></div>
            <?php if ($item['location_found']): ?>
            <div style="font-size:11px;color:var(--white-dim)">📍 <?= htmlspecialchars($item['location_found']) ?></div>
            <?php endif; ?>
          </div>
        </a>
        <?php endforeach; ?>
        <?php if (empty($recentFound)): ?>
        <div style="grid-column:span 2;text-align:center;color:var(--white-dim);padding:30px;">No found items yet.</div>
        <?php endif; ?>
      </div>
    </div>

    <!-- My Claims -->
    <?php if (!empty($myRecentClaims)): ?>
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">My Recent Claims</h2>
        <a href="/user/my-claims.php" class="btn btn-ghost btn-sm">All Claims</a>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Item</th><th>Ref #</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
            <?php foreach ($myRecentClaims as $cl): ?>
            <tr>
              <td style="font-weight:500"><?= htmlspecialchars($cl['item_name']) ?></td>
              <td style="font-family:monospace;font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($cl['reference_no']) ?></td>
              <td><span class="badge badge-<?= $cl['status'] ?>"><?= ucfirst($cl['status']) ?></span></td>
              <td style="font-size:12px;color:var(--white-dim)"><?= date('M d, Y', strtotime($cl['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Notifications sidebar -->
  <div>
    <div class="card">
      <div class="card-header">
        <h2 class="card-title" style="font-size:18px;">Notifications</h2>
        <a href="/user/notifications.php" class="btn btn-ghost btn-sm">All</a>
      </div>
      <?php if (empty($notifs)): ?>
      <p style="color:var(--white-dim);font-size:13px;text-align:center;padding:16px">No notifications yet.</p>
      <?php else: ?>
      <?php foreach ($notifs as $n): ?>
      <div style="padding:12px;border-radius:8px;margin-bottom:8px;background:<?= $n['is_read'] ? 'transparent' : 'rgba(77,130,255,0.05)' ?>;border:1px solid <?= $n['is_read'] ? 'transparent' : 'rgba(77,130,255,0.15)' ?>;">
        <div style="font-size:13px;font-weight:<?= $n['is_read'] ? '400' : '500' ?>;margin-bottom:4px;"><?= htmlspecialchars($n['title']) ?></div>
        <div style="font-size:12px;color:var(--white-dim);line-height:1.5;"><?= htmlspecialchars($n['message']) ?></div>
        <div style="font-size:11px;color:var(--white-dim);margin-top:6px;"><?= date('M d, g:i A', strtotime($n['created_at'])) ?></div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Quick Actions -->
    <div class="card" style="margin-top:16px;">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:.15em;color:var(--white-dim);margin-bottom:12px;">Quick Actions</div>
      <a href="/user/items.php" class="btn btn-primary" style="width:100%;justify-content:center;margin-bottom:8px;">Browse Found Items</a>
      <a href="/user/my-claims.php" class="btn btn-ghost" style="width:100%;justify-content:center;">My Claims</a>
    </div>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
