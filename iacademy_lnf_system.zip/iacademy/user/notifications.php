<?php
// ============================================
// iAcademy Lost & Found — Notifications
// user/notifications.php  (also used by admin via symlink or copy)
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$pdo  = getPDO();
$user = currentUser();

// Mark all as read
if (isset($_GET['mark_all'])) {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$user['id']]);
    header('Location: /user/notifications.php');
    exit;
}

// Mark single as read
if (isset($_GET['mark'])) {
    $nid = (int)$_GET['mark'];
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?")->execute([$nid, $user['id']]);
}

$notifs = $pdo->prepare(
    "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 60"
);
$notifs->execute([$user['id']]);
$notifs = $notifs->fetchAll();

$unread = array_filter($notifs, fn($n) => !$n['is_read']);

$typeIcons = [
    'success' => '✅',
    'error'   => '❌',
    'warning' => '⚠️',
    'info'    => 'ℹ️',
];

$pageTitle = 'Notifications';
include __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
  <div style="font-size:13px;color:var(--white-dim);">
    <?= count($unread) ?> unread notification<?= count($unread) !== 1 ? 's' : '' ?>
  </div>
  <?php if (!empty($unread)): ?>
  <a href="?mark_all=1" class="btn btn-ghost btn-sm">Mark all as read</a>
  <?php endif; ?>
</div>

<?php if (empty($notifs)): ?>
<div style="text-align:center;padding:80px;color:var(--white-dim);">
  <div style="font-size:48px;margin-bottom:16px;">🔔</div>
  <div>No notifications yet.</div>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:8px;max-width:720px;">
  <?php foreach ($notifs as $n): ?>
  <div style="padding:18px 20px;border-radius:10px;border:1px solid <?= $n['is_read'] ? 'var(--white-line)' : 'rgba(77,130,255,0.25)' ?>;background:<?= $n['is_read'] ? 'rgba(255,255,255,0.03)' : 'rgba(77,130,255,0.06)' ?>;transition:all .15s;display:flex;gap:14px;align-items:flex-start;">
    <div style="font-size:20px;flex-shrink:0;margin-top:1px;"><?= $typeIcons[$n['type']] ?? 'ℹ️' ?></div>
    <div style="flex:1;min-width:0;">
      <div style="font-weight:<?= $n['is_read'] ? '400' : '500' ?>;font-size:14px;margin-bottom:4px;">
        <?= htmlspecialchars($n['title']) ?>
        <?php if (!$n['is_read']): ?><span style="display:inline-block;width:7px;height:7px;background:var(--blue-accent);border-radius:50%;margin-left:8px;vertical-align:middle;"></span><?php endif; ?>
      </div>
      <div style="font-size:13px;color:var(--white-dim);line-height:1.6;"><?= htmlspecialchars($n['message']) ?></div>
      <div style="font-size:11px;color:var(--white-dim);margin-top:8px;"><?= date('F d, Y · g:i A', strtotime($n['created_at'])) ?></div>
    </div>
    <div style="flex-shrink:0;display:flex;gap:6px;align-items:center;">
      <?php if ($n['link']): ?>
      <a href="<?= htmlspecialchars($n['link']) ?>?mark=<?= $n['id'] ?>" class="btn btn-ghost btn-sm">View →</a>
      <?php endif; ?>
      <?php if (!$n['is_read']): ?>
      <a href="?mark=<?= $n['id'] ?>" class="btn btn-ghost btn-sm">Mark read</a>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
