<?php
// ============================================
// iAcademy Lost & Found — User Browse Items
// user/items.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('user');

$pdo = getPDO();

$search   = trim($_GET['q']        ?? '');
$category = (int)($_GET['category'] ?? 0);
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 12;
$offset   = ($page - 1) * $perPage;

$where  = ["i.status IN ('found','turned_in')", "i.is_archived = 0"];
$params = [];

if ($search)   { $where[] = "(i.item_name LIKE ? OR i.description LIKE ?)"; $params = array_merge($params, ["%$search%","%$search%"]); }
if ($category) { $where[] = "i.category_id = ?"; $params[] = $category; }

$whereSQL = implode(' AND ', $where);

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM items i WHERE $whereSQL");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = (int)ceil($total / $perPage);

$itemsStmt = $pdo->prepare(
    "SELECT i.id, i.item_name, i.reference_no, i.status, i.location_found, i.date_reported,
            c.name AS category,
            (SELECT image_path FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) AS primary_image
     FROM items i
     JOIN categories c ON i.category_id = c.id
     WHERE $whereSQL
     ORDER BY i.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$itemsStmt->execute($params);
$items = $itemsStmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$pageTitle   = 'Browse Items';
include __DIR__ . '/../includes/header.php';
?>

<!-- Search & Filter Bar -->
<form method="GET" style="display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;">
  <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
         placeholder="Search lost and found items..."
         style="flex:1;min-width:200px;padding:10px 16px;background:var(--white-ghost);border:1px solid var(--white-line);border-radius:8px;color:var(--white);font-family:var(--font-body);font-size:13.5px;">
  <select name="category" style="padding:10px 14px;background:var(--white-ghost);border:1px solid var(--white-line);border-radius:8px;color:var(--white);font-family:var(--font-body);font-size:13px;">
    <option value="">All Categories</option>
    <?php foreach ($categories as $cat): ?>
    <option value="<?= $cat['id'] ?>" <?= $category === (int)$cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit" class="btn btn-primary">Search</button>
  <?php if ($search || $category): ?><a href="/user/items.php" class="btn btn-ghost">Clear</a><?php endif; ?>
</form>

<div style="font-size:13px;color:var(--white-dim);margin-bottom:16px;"><?= $total ?> item<?= $total !== 1 ? 's' : '' ?> found</div>

<!-- Items Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;margin-bottom:28px;">
  <?php foreach ($items as $item): ?>
  <a href="/user/item-view.php?id=<?= $item['id'] ?>" style="text-decoration:none;">
    <div style="background:rgba(255,255,255,0.04);border:1px solid var(--white-line);border-radius:12px;overflow:hidden;transition:all .15s;cursor:pointer;"
         onmouseover="this.style.borderColor='var(--blue-accent)';this.style.transform='translateY(-2px)'"
         onmouseout="this.style.borderColor='var(--white-line)';this.style.transform='translateY(0)'">
      <?php if ($item['primary_image']): ?>
      <img src="/<?= htmlspecialchars($item['primary_image']) ?>" alt="" style="width:100%;height:140px;object-fit:cover;">
      <?php else: ?>
      <div style="width:100%;height:140px;background:rgba(77,130,255,0.08);display:flex;align-items:center;justify-content:center;font-size:36px;">📦</div>
      <?php endif; ?>
      <div style="padding:14px;">
        <div style="font-size:11px;color:var(--blue-accent);text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px;"><?= htmlspecialchars($item['category']) ?></div>
        <div style="font-weight:500;font-size:14px;margin-bottom:8px;line-height:1.3;"><?= htmlspecialchars($item['item_name']) ?></div>
        <?php if ($item['location_found']): ?>
        <div style="font-size:12px;color:var(--white-dim);margin-bottom:6px;">📍 <?= htmlspecialchars($item['location_found']) ?></div>
        <?php endif; ?>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span class="badge badge-<?= $item['status'] ?>"><?= ucfirst(str_replace('_',' ',$item['status'])) ?></span>
          <span style="font-size:11px;color:var(--white-dim)"><?= date('M d', strtotime($item['date_reported'])) ?></span>
        </div>
      </div>
    </div>
  </a>
  <?php endforeach; ?>
  <?php if (empty($items)): ?>
  <div style="grid-column:1/-1;text-align:center;color:var(--white-dim);padding:60px">
    <div style="font-size:48px;margin-bottom:12px">🔍</div>
    <div>No items found<?= ($search || $category) ? ' matching your search' : '' ?>.</div>
    <?php if ($search || $category): ?><a href="/user/items.php" style="color:var(--blue-accent);text-decoration:none;font-size:13px;display:block;margin-top:8px;">Clear filters</a><?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Pagination -->
<?php if ($pages > 1): ?>
<div class="pagination">
  <?php for ($i = 1; $i <= $pages; $i++): ?>
  <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&category=<?= $category ?>"
     class="page-btn <?= $i === $page ? 'current' : '' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
