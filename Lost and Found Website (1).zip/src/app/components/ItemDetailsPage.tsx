import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import { Header } from './Header';
import { Footer } from './Footer';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowLeft, Calendar, Clock, MapPin, Package, AlertCircle } from 'lucide-react';
import { mockItems } from '../data/mockData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Alert, AlertDescription } from './ui/alert';

export function ItemDetailsPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const item = mockItems.find(i => i.id === id);

  if (!item) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">Item not found</p>
              <Button onClick={() => navigate('/dashboard')} className="mt-4">
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header />
      
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        <Button
          variant="ghost"
          onClick={() => navigate('/dashboard')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Image Section */}
          <Card className="overflow-hidden">
            <div className="aspect-square w-full bg-gray-100 dark:bg-gray-800">
              <ImageWithFallback
                src={item.imageUrl || ''}
                alt={item.name}
                className="w-full h-full object-cover"
              />
            </div>
          </Card>

          {/* Details Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-2xl">{item.name}</CardTitle>
                  <Badge 
                    variant={item.status === 'available' ? 'default' : 'secondary'}
                    className={item.status === 'available' ? 'bg-blue-600' : 'bg-gray-400'}
                  >
                    {item.status === 'available' ? 'Available' : 'Claimed'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Basic Info - Visible to All */}
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <Package className="w-4 h-4 mr-3 text-muted-foreground flex-shrink-0" />
                    <span className="text-muted-foreground mr-2">Category:</span>
                    <span className="capitalize font-medium">{item.category}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Package className="w-4 h-4 mr-3 text-muted-foreground flex-shrink-0" />
                    <span className="text-muted-foreground mr-2">Quantity:</span>
                    <span className="font-medium">{item.quantity}</span>
                  </div>
                </div>

                {isAdmin ? (
                  /* Full Details - Admin Only */
                  <>
                    <div className="pt-4 border-t space-y-3">
                      <h4 className="font-semibold text-sm text-blue-600">Full Details (Admin View)</h4>
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Description</p>
                          <p className="text-sm">{item.description}</p>
                        </div>
                        <div className="flex items-start text-sm">
                          <Calendar className="w-4 h-4 mr-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                          <div>
                            <span className="text-muted-foreground mr-2">Date Found:</span>
                            <span className="font-medium">
                              {new Date(item.dateFound).toLocaleDateString('en-US', { 
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                              })}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-start text-sm">
                          <Clock className="w-4 h-4 mr-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                          <div>
                            <span className="text-muted-foreground mr-2">Time Found:</span>
                            <span className="font-medium">{item.timeFound}</span>
                          </div>
                        </div>
                        <div className="flex items-start text-sm">
                          <MapPin className="w-4 h-4 mr-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                          <div>
                            <span className="text-muted-foreground mr-2">Place Found:</span>
                            <span className="font-medium">{item.placeFound}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  /* Limited Details - Member View */
                  <>
                    <Alert className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
                      <AlertCircle className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-sm text-blue-900 dark:text-blue-100">
                        Full item details are restricted to admins to prevent theft or false claims.
                        Submit a claim request to verify ownership.
                      </AlertDescription>
                    </Alert>
                  </>
                )}

                {/* Action Buttons */}
                {item.status === 'available' && (
                  <div className="pt-4">
                    <Link to={`/claim/${item.id}`} className="w-full block">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        {isAdmin ? 'View Claim Requests' : 'Submit Claim Request'}
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}