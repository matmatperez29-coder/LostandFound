import React from 'react';

export function Footer() {
  return (
    <footer className="border-t bg-white dark:bg-gray-900 mt-auto">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">iA</span>
            </div>
            <div>
              <p className="text-sm font-medium">I-C-IT Lost & Found</p>
              <p className="text-xs text-muted-foreground">See It. Claim It. Find It.</p>
            </div>
          </div>
          <div className="text-center md:text-right">
            <p className="text-xs text-muted-foreground">
              © 2026 iACADEMY. All rights reserved.
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Student Services Office
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
