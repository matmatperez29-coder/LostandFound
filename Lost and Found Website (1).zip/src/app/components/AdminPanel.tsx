import React, { useState } from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Plus, Edit, Trash2, Eye, CheckCircle, XCircle, MessageSquare } from 'lucide-react';
import { mockItems, mockClaimRequests } from '../data/mockData';
import { ItemCategory, ItemStatus } from '../types';
import { toast } from 'sonner';

export function AdminPanel() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState(mockItems);
  const [claims, setClaims] = useState(mockClaimRequests);
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);

  // New item form state
  const [newItemName, setNewItemName] = useState('');
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<ItemCategory>('others');
  const [newItemQuantity, setNewItemQuantity] = useState('1');
  const [newItemTimeFound, setNewItemTimeFound] = useState('');
  const [newItemDateFound, setNewItemDateFound] = useState('');
  const [newItemPlaceFound, setNewItemPlaceFound] = useState('');

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-red-600">Access Denied: Admin Only</p>
              <Button onClick={() => navigate('/dashboard')} className="mt-4">
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  const handleAddItem = () => {
    const newItem = {
      id: String(items.length + 1),
      name: newItemName,
      description: newItemDescription,
      category: newItemCategory,
      status: 'available' as ItemStatus,
      quantity: parseInt(newItemQuantity),
      timeFound: newItemTimeFound,
      dateFound: newItemDateFound,
      placeFound: newItemPlaceFound,
      createdAt: new Date().toISOString(),
    };

    setItems([...items, newItem]);
    setIsAddItemOpen(false);
    toast.success('Item posted successfully!');
    
    // Reset form
    setNewItemName('');
    setNewItemDescription('');
    setNewItemCategory('others');
    setNewItemQuantity('1');
    setNewItemTimeFound('');
    setNewItemDateFound('');
    setNewItemPlaceFound('');
  };

  const handleDeleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
    toast.success('Item deleted successfully');
  };

  const handleUpdateItemStatus = (id: string, status: ItemStatus) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, status } : item
    ));
    toast.success(`Item marked as ${status}`);
  };

  const handleApproveClaim = (claimId: string) => {
    setClaims(claims.map(claim =>
      claim.id === claimId ? { ...claim, status: 'approved' as const } : claim
    ));
    toast.success('Claim approved successfully');
  };

  const handleRejectClaim = (claimId: string) => {
    setClaims(claims.map(claim =>
      claim.id === claimId ? { ...claim, status: 'rejected' as const } : claim
    ));
    toast.success('Claim rejected');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-blue-900 dark:text-blue-100 mb-2">Admin Panel</h1>
          <p className="text-muted-foreground">Manage lost items and claim requests</p>
        </div>

        <Tabs defaultValue="items" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-md">
            <TabsTrigger value="items">Items</TabsTrigger>
            <TabsTrigger value="claims">
              Claims
              {claims.filter(c => c.status === 'pending').length > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {claims.filter(c => c.status === 'pending').length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
          </TabsList>

          {/* Items Management */}
          <TabsContent value="items" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Lost Items</h2>
              <Dialog open={isAddItemOpen} onOpenChange={setIsAddItemOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Item
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add Lost Item</DialogTitle>
                    <DialogDescription>
                      Enter the details of the found item
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="itemName">Item Name *</Label>
                      <Input
                        id="itemName"
                        value={newItemName}
                        onChange={(e) => setNewItemName(e.target.value)}
                        placeholder="e.g., iPhone 14 Pro"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="itemDescription">Description *</Label>
                      <Textarea
                        id="itemDescription"
                        value={newItemDescription}
                        onChange={(e) => setNewItemDescription(e.target.value)}
                        placeholder="Detailed description of the item"
                        rows={3}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="itemCategory">Category *</Label>
                        <Select value={newItemCategory} onValueChange={(value) => setNewItemCategory(value as ItemCategory)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="gadgets">Gadgets</SelectItem>
                            <SelectItem value="ids">IDs</SelectItem>
                            <SelectItem value="bags">Bags</SelectItem>
                            <SelectItem value="clothing">Clothing</SelectItem>
                            <SelectItem value="others">Others</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="itemQuantity">Quantity *</Label>
                        <Input
                          id="itemQuantity"
                          type="number"
                          min="1"
                          value={newItemQuantity}
                          onChange={(e) => setNewItemQuantity(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="dateFound">Date Found *</Label>
                        <Input
                          id="dateFound"
                          type="date"
                          value={newItemDateFound}
                          onChange={(e) => setNewItemDateFound(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="timeFound">Time Found *</Label>
                        <Input
                          id="timeFound"
                          type="time"
                          value={newItemTimeFound}
                          onChange={(e) => setNewItemTimeFound(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="placeFound">Place Found *</Label>
                      <Input
                        id="placeFound"
                        value={newItemPlaceFound}
                        onChange={(e) => setNewItemPlaceFound(e.target.value)}
                        placeholder="e.g., Library Entrance, 1st Floor"
                      />
                    </div>
                    <Button
                      onClick={handleAddItem}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      disabled={!newItemName || !newItemDescription || !newItemDateFound || !newItemTimeFound || !newItemPlaceFound}
                    >
                      Add Item
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Date Found</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="capitalize">{item.category}</TableCell>
                        <TableCell>{new Date(item.dateFound).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === 'available' ? 'default' : 'secondary'}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => navigate(`/item/${item.id}`)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Select
                              value={item.status}
                              onValueChange={(value) => handleUpdateItemStatus(item.id, value as ItemStatus)}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="available">Available</SelectItem>
                                <SelectItem value="claimed">Claimed</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteItem(item.id)}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Claims Management */}
          <TabsContent value="claims" className="space-y-4">
            <h2 className="text-xl font-semibold">Claim Requests</h2>
            <div className="space-y-4">
              {claims.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center text-muted-foreground">
                    No claim requests yet
                  </CardContent>
                </Card>
              ) : (
                claims.map((claim) => (
                  <Card key={claim.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{claim.itemName}</CardTitle>
                          <p className="text-sm text-muted-foreground mt-1">
                            Requested by: {claim.userName} ({claim.userEmail})
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(claim.createdAt).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={claim.messageType === 'verification' ? 'default' : 'secondary'}>
                            {claim.messageType === 'verification' ? 'Verification' : 'Meet-Up'}
                          </Badge>
                          <Badge
                            variant={
                              claim.status === 'pending' ? 'outline' :
                              claim.status === 'approved' ? 'default' : 'destructive'
                            }
                            className={
                              claim.status === 'approved' ? 'bg-green-600' : ''
                            }
                          >
                            {claim.status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {claim.messageType === 'verification' && claim.verificationData && (
                        <div className="space-y-3 text-sm">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-muted-foreground">Contact Number:</p>
                              <p className="font-medium">{claim.verificationData.contactNumber}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Color:</p>
                              <p className="font-medium">{claim.verificationData.color}</p>
                            </div>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Item Description:</p>
                            <p className="font-medium">{claim.verificationData.itemDescription}</p>
                          </div>
                          {claim.verificationData.brand && (
                            <div>
                              <p className="text-muted-foreground">Brand:</p>
                              <p className="font-medium">{claim.verificationData.brand}</p>
                            </div>
                          )}
                          <div>
                            <p className="text-muted-foreground">Unique Identifiers:</p>
                            <p className="font-medium">{claim.verificationData.uniqueIdentifiers}</p>
                          </div>
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <p className="text-muted-foreground">Date Lost:</p>
                              <p className="font-medium">{claim.verificationData.dateLost}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Time Lost:</p>
                              <p className="font-medium">{claim.verificationData.timeLost}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Place Lost:</p>
                              <p className="font-medium">{claim.verificationData.placeLost}</p>
                            </div>
                          </div>
                          {claim.verificationData.additionalNotes && (
                            <div>
                              <p className="text-muted-foreground">Additional Notes:</p>
                              <p className="font-medium">{claim.verificationData.additionalNotes}</p>
                            </div>
                          )}
                        </div>
                      )}
                      {claim.messageType === 'meetup' && claim.meetupData && (
                        <div className="space-y-3 text-sm">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-muted-foreground">Contact Number:</p>
                              <p className="font-medium">{claim.meetupData.contactNumber}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Preferred Date:</p>
                              <p className="font-medium">{claim.meetupData.preferredDate}</p>
                            </div>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Preferred Time:</p>
                            <p className="font-medium">{claim.meetupData.preferredTime}</p>
                          </div>
                          {claim.meetupData.message && (
                            <div>
                              <p className="text-muted-foreground">Message:</p>
                              <p className="font-medium">{claim.meetupData.message}</p>
                            </div>
                          )}
                        </div>
                      )}
                      {claim.status === 'pending' && (
                        <div className="flex gap-2 mt-4">
                          <Button
                            onClick={() => handleApproveClaim(claim.id)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            onClick={() => handleRejectClaim(claim.id)}
                            variant="destructive"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Reject
                          </Button>
                          <Button variant="outline">
                            <MessageSquare className="w-4 h-4 mr-2" />
                            Send Message
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Statistics */}
          <TabsContent value="stats" className="space-y-4">
            <h2 className="text-xl font-semibold">Statistics</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm text-muted-foreground">Total Items</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{items.length}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm text-muted-foreground">Available Items</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600">
                    {items.filter(i => i.status === 'available').length}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm text-muted-foreground">Claimed Items</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">
                    {items.filter(i => i.status === 'claimed').length}
                  </p>
                </CardContent>
              </Card>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm text-muted-foreground">Pending Claims</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-orange-600">
                    {claims.filter(c => c.status === 'pending').length}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm text-muted-foreground">Approved Claims</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">
                    {claims.filter(c => c.status === 'approved').length}
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      <Footer />
    </div>
  );
}