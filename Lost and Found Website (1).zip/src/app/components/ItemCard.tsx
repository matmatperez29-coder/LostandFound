import React from 'react';
import { Link } from 'react-router';
import { LostItem } from '../types';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Calendar, MapPin, Package } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ItemCardProps {
  item: LostItem;
}

export function ItemCard({ item }: ItemCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-video w-full overflow-hidden bg-gray-100 dark:bg-gray-800">
        <ImageWithFallback
          src={item.imageUrl || ''}
          alt={item.name}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-lg line-clamp-1">{item.name}</h3>
          <Badge 
            variant={item.status === 'available' ? 'default' : 'secondary'}
            className={item.status === 'available' ? 'bg-blue-600' : 'bg-gray-400'}
          >
            {item.status === 'available' ? 'Available' : 'Claimed'}
          </Badge>
        </div>
        <div className="space-y-1 text-sm text-muted-foreground">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className="line-clamp-1">{new Date(item.dateFound).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className="line-clamp-1">{item.placeFound}</span>
          </div>
          <div className="flex items-center">
            <Package className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className="capitalize">{item.category}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link to={`/item/${item.id}`} className="w-full">
          <Button variant="outline" className="w-full">
            View Details
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
