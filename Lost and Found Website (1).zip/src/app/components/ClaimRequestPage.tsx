import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Header } from './Header';
import { Footer } from './Footer';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { mockItems } from '../data/mockData';
import { MessageType } from '../types';
import { toast } from 'sonner';

export function ClaimRequestPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [messageType, setMessageType] = useState<MessageType>('verification');
  const [submitted, setSubmitted] = useState(false);
  
  const item = mockItems.find(i => i.id === id);

  // Verification form state
  const [fullName, setFullName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [contactNumber, setContactNumber] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [brand, setBrand] = useState('');
  const [color, setColor] = useState('');
  const [uniqueIdentifiers, setUniqueIdentifiers] = useState('');
  const [dateLost, setDateLost] = useState('');
  const [timeLost, setTimeLost] = useState('');
  const [placeLost, setPlaceLost] = useState('');
  const [contents, setContents] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');

  // Meet-up form state
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('');
  const [message, setMessage] = useState('');

  if (!item) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <p className="text-center text-muted-foreground">Item not found</p>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulate submission
    setSubmitted(true);
    
    if (messageType === 'verification') {
      toast.success('Verification request submitted successfully!', {
        description: 'Our admin team will review your request and respond within 24-48 hours.',
      });
    } else {
      toast.success('Meet-up request submitted successfully!', {
        description: 'Our admin team will review your preferred schedule and get back to you soon.',
      });
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <Header />
        <main className="container mx-auto px-4 py-8 max-w-2xl">
          <Card className="text-center p-8">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <CardTitle className="text-2xl mb-2">Request Submitted!</CardTitle>
            <CardDescription className="mb-6">
              {messageType === 'verification' ? (
                <>
                  <p className="mb-2">Your verification request has been received by our admin team.</p>
                  <p>We will review your submitted details and respond within 24-48 hours.</p>
                </>
              ) : (
                <>
                  <p className="mb-2">Your meet-up request has been received by our admin team.</p>
                  <p>We will review your preferred schedule and confirm or suggest an alternative time.</p>
                </>
              )}
            </CardDescription>
            <div className="space-y-2">
              <Button onClick={() => navigate('/dashboard')} className="w-full bg-blue-600 hover:bg-blue-700">
                Back to Dashboard
              </Button>
              <Button onClick={() => navigate(`/item/${id}`)} variant="outline" className="w-full">
                View Item Details
              </Button>
            </div>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header />
      
      <main className="container mx-auto px-4 py-8 max-w-3xl">
        <Button
          variant="ghost"
          onClick={() => navigate(`/item/${id}`)}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Item
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Submit Claim Request</CardTitle>
            <CardDescription>
              Claiming: <span className="font-medium text-foreground">{item.name}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Message Type Selection */}
              <div className="space-y-3">
                <Label>Select Message Type</Label>
                <RadioGroup value={messageType} onValueChange={(value) => setMessageType(value as MessageType)}>
                  <div className="flex items-start space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                    <RadioGroupItem value="verification" id="verification" />
                    <div className="flex-1">
                      <Label htmlFor="verification" className="cursor-pointer font-medium">
                        Verification Message
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        Provide details to prove ownership of the item
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                    <RadioGroupItem value="meetup" id="meetup" />
                    <div className="flex-1">
                      <Label htmlFor="meetup" className="cursor-pointer font-medium">
                        Meet-Up Request
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        Schedule an in-person meeting to claim the item
                      </p>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              {messageType === 'verification' ? (
                /* Verification Form */
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input
                        id="fullName"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">iACADEMY Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contactNumber">Contact Number *</Label>
                    <Input
                      id="contactNumber"
                      type="tel"
                      placeholder="09XX XXX XXXX"
                      value={contactNumber}
                      onChange={(e) => setContactNumber(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="itemDescription">Item Description *</Label>
                    <Textarea
                      id="itemDescription"
                      placeholder="Describe the item in detail"
                      value={itemDescription}
                      onChange={(e) => setItemDescription(e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="brand">Brand (if applicable)</Label>
                      <Input
                        id="brand"
                        placeholder="e.g., Apple, Samsung"
                        value={brand}
                        onChange={(e) => setBrand(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="color">Color *</Label>
                      <Input
                        id="color"
                        placeholder="e.g., Black, Blue"
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="uniqueIdentifiers">Unique Identifiers *</Label>
                    <Textarea
                      id="uniqueIdentifiers"
                      placeholder="Scratches, stickers, marks, custom settings, etc."
                      value={uniqueIdentifiers}
                      onChange={(e) => setUniqueIdentifiers(e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="dateLost">Date Lost *</Label>
                      <Input
                        id="dateLost"
                        type="date"
                        value={dateLost}
                        onChange={(e) => setDateLost(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="timeLost">Time Lost *</Label>
                      <Input
                        id="timeLost"
                        type="time"
                        value={timeLost}
                        onChange={(e) => setTimeLost(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2 md:col-span-1">
                      <Label htmlFor="placeLost">Place Lost *</Label>
                      <Input
                        id="placeLost"
                        placeholder="e.g., Library"
                        value={placeLost}
                        onChange={(e) => setPlaceLost(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contents">Contents of the Item (if applicable)</Label>
                    <Textarea
                      id="contents"
                      placeholder="What was inside? (e.g., apps, files, personal items)"
                      value={contents}
                      onChange={(e) => setContents(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="additionalNotes">Additional Notes</Label>
                    <Textarea
                      id="additionalNotes"
                      placeholder="Any other information that might help verify ownership"
                      value={additionalNotes}
                      onChange={(e) => setAdditionalNotes(e.target.value)}
                    />
                  </div>
                </div>
              ) : (
                /* Meet-Up Request Form */
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="meetupFullName">Full Name *</Label>
                      <Input
                        id="meetupFullName"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="meetupEmail">iACADEMY Email *</Label>
                      <Input
                        id="meetupEmail"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="meetupContactNumber">Contact Number *</Label>
                    <Input
                      id="meetupContactNumber"
                      type="tel"
                      placeholder="09XX XXX XXXX"
                      value={contactNumber}
                      onChange={(e) => setContactNumber(e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="preferredDate">Preferred Date *</Label>
                      <Input
                        id="preferredDate"
                        type="date"
                        value={preferredDate}
                        onChange={(e) => setPreferredDate(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="preferredTime">Preferred Time *</Label>
                      <Input
                        id="preferredTime"
                        type="time"
                        value={preferredTime}
                        onChange={(e) => setPreferredTime(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message/Note (optional)</Label>
                    <Textarea
                      id="message"
                      placeholder="Any additional information or special requests"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      rows={4}
                    />
                  </div>
                </div>
              )}

              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Submit Request
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
}