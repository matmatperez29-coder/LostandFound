export type ItemCategory = 'gadgets' | 'ids' | 'bags' | 'clothing' | 'others';
export type ItemStatus = 'available' | 'claimed';
export type MessageType = 'verification' | 'meetup';
export type ClaimStatus = 'pending' | 'approved' | 'rejected';

export interface LostItem {
  id: string;
  name: string;
  description: string;
  category: ItemCategory;
  status: ItemStatus;
  quantity: number;
  timeFound: string;
  dateFound: string;
  placeFound: string;
  imageUrl?: string;
  createdAt: string;
}

export interface VerificationRequest {
  fullName: string;
  email: string;
  contactNumber: string;
  itemDescription: string;
  brand?: string;
  color: string;
  uniqueIdentifiers: string;
  dateLost: string;
  timeLost: string;
  placeLost: string;
  contents?: string;
  proofOfOwnership?: File;
  additionalNotes?: string;
}

export interface MeetUpRequest {
  fullName: string;
  email: string;
  contactNumber: string;
  preferredDate: string;
  preferredTime: string;
  message?: string;
}

export interface ClaimRequest {
  id: string;
  itemId: string;
  itemName: string;
  userId: string;
  userName: string;
  userEmail: string;
  messageType: MessageType;
  verificationData?: VerificationRequest;
  meetupData?: MeetUpRequest;
  status: ClaimStatus;
  createdAt: string;
  adminResponse?: string;
  respondedAt?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning';
  read: boolean;
  createdAt: string;
}
