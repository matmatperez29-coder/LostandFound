import { createBrowserRouter } from 'react-router';
import { LoginPage } from './components/LoginPage';
import { DashboardPage } from './components/DashboardPage';
import { ItemDetailsPage } from './components/ItemDetailsPage';
import { ClaimRequestPage } from './components/ClaimRequestPage';
import { AdminPanel } from './components/AdminPanel';
import { SupportPage } from './components/SupportPage';
import { ProtectedRoute } from './components/ProtectedRoute';

export const router = createBrowserRouter([
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/',
    Component: ProtectedRoute,
    children: [
      {
        path: '/',
        Component: DashboardPage,
      },
      {
        path: '/dashboard',
        Component: DashboardPage,
      },
      {
        path: '/item/:id',
        Component: ItemDetailsPage,
      },
      {
        path: '/claim/:id',
        Component: ClaimRequestPage,
      },
      {
        path: '/admin',
        Component: AdminPanel,
      },
      {
        path: '/support',
        Component: SupportPage,
      },
    ],
  },
]);
