<?php
// ============================================
// iAcademy Lost & Found — Admin Claim Review
// admin/claim-review.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();
$id  = (int)($_GET['id'] ?? 0);
$admin = currentUser();
$success = $error = '';

// Load claim
$claimStmt = $pdo->prepare(
    "SELECT cl.*, i.item_name, i.reference_no, i.id AS item_id, i.status AS item_status,
            u.first_name, u.last_name, u.email, u.student_id, u.id AS claimant_user_id
     FROM claims cl
     JOIN items i ON cl.item_id = i.id
     JOIN users u ON cl.claimant_id = u.id
     WHERE cl.id = ?"
);
$claimStmt->execute([$id]);
$claim = $claimStmt->fetch();

if (!$claim) { header('Location: /admin/claims.php'); exit; }

// Handle approve/reject
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action     = $_POST['action']     ?? '';
    $admin_note = trim($_POST['admin_note'] ?? '');

    if (in_array($action, ['approved','rejected'])) {
        $pdo->prepare(
            "UPDATE claims SET status=?, reviewed_by=?, reviewed_at=NOW(), admin_note=? WHERE id=?"
        )->execute([$action, $admin['id'], $admin_note, $id]);

        if ($action === 'approved') {
            // Mark item as claimed
            $pdo->prepare("UPDATE items SET status='claimed' WHERE id=?")->execute([$claim['item_id']]);
        }

        // Notify claimant
        $notifTitle = $action === 'approved' ? 'Claim Approved! 🎉' : 'Claim Rejected';
        
        // ---> UPDATED NOTIFICATION LOGIC <---
        $notifMsg   = $action === 'approved'
            ? "Your claim for \"{$claim['item_name']}\" has been approved. " . ($admin_note ? "Meeting Details: " . $admin_note : "Please coordinate with the admin for pickup.")
            : "Your claim for \"{$claim['item_name']}\" was not approved. Reason: " . ($admin_note ?: 'No reason provided.');
            
        $notifType  = $action === 'approved' ? 'success' : 'error';

        $pdo->prepare(
            "INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)"
        )->execute([$claim['claimant_user_id'], $notifTitle, $notifMsg, $notifType,
                    '/user/my-claims.php']);

        // Activity log
        $pdo->prepare("INSERT INTO activity_log (actor_id, action, target_type, target_id, ip_address) VALUES (?,?,?,?,?)")
            ->execute([$admin['id'], 'claim.'.$action, 'claim', $id, $_SERVER['REMOTE_ADDR'] ?? null]);

        $success = "Claim {$action} successfully.";
        // Reload
        $claimStmt->execute([$id]);
        $claim = $claimStmt->fetch();
    }
}

$pageTitle = 'Claim Review';
include __DIR__ . '/../includes/header.php';
?>

<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div style="display:flex;gap:8px;margin-bottom:20px;">
  <a href="/admin/claims.php" class="btn btn-ghost btn-sm">← All Claims</a>
  <a href="/admin/item-view.php?id=<?= $claim['item_id'] ?>" class="btn btn-ghost btn-sm">View Item</a>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">

  <div>
    <div class="card" style="margin-bottom:20px;">
      <div class="card-header">
        <h2 class="card-title">Claim Details</h2>
        <span class="badge badge-<?= $claim['status'] ?>"><?= ucfirst($claim['status']) ?></span>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Item</div>
          <div style="font-weight:500;"><?= htmlspecialchars($claim['item_name']) ?></div>
          <div style="font-family:monospace;font-size:11px;color:var(--white-dim)"><?= htmlspecialchars($claim['reference_no']) ?></div>
        </div>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Submitted</div>
          <div><?= date('F d, Y H:i', strtotime($claim['created_at'])) ?></div>
        </div>
        <div>
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:4px;">Claimant</div>
          <div style="font-weight:500;"><?= htmlspecialchars($claim['first_name'].' '.$claim['last_name']) ?></div>
          <div style="font-size:12px;color:var(--white-dim)"><?= htmlspecialchars($claim['email']) ?></div>
          <?php if ($claim['student_id']): ?>
          <div style="font-size:12px;color:var(--blue-accent)">ID: <?= htmlspecialchars($claim['student_id']) ?></div>
          <?php endif; ?>
        </div>
      </div>

      <?php if ($claim['claim_note']): ?>
      <div style="padding:16px;background:var(--white-ghost);border-radius:8px;margin-bottom:16px;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:8px;">Claimant's Note</div>
        <p style="font-size:14px;line-height:1.7;color:var(--white-soft)"><?= nl2br(htmlspecialchars($claim['claim_note'])) ?></p>
      </div>
      <?php endif; ?>

      <?php if ($claim['proof_path']): ?>
      <div style="margin-bottom:16px;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--white-dim);margin-bottom:8px;">Proof of Ownership</div>
        <?php
        $ext = strtolower(pathinfo($claim['proof_path'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])): ?>
        <img src="/<?= htmlspecialchars($claim['proof_path']) ?>" alt="Proof"
             style="max-width:100%;border-radius:8px;border:1px solid var(--white-line);">
        <?php else: ?>
        <a href="/<?= htmlspecialchars($claim['proof_path']) ?>" target="_blank" class="btn btn-ghost btn-sm">Download Proof File</a>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <?php if ($claim['admin_note']): ?>
      <div style="padding:16px;background:rgba(77,130,255,0.08);border:1px solid rgba(77,130,255,0.2);border-radius:8px;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--blue-accent);margin-bottom:6px;">Admin Note</div>
        <p style="font-size:13.5px;color:var(--white-soft)"><?= nl2br(htmlspecialchars($claim['admin_note'])) ?></p>
      </div>
      <?php endif; ?>
    </div>

    <?php if ($claim['status'] === 'pending'): ?>
    <div class="card">
      <div class="card-header"><h2 class="card-title">Review Decision</h2></div>
      <form method="POST">
        <div class="field">
          <label>Admin Note (optional)</label>
          <textarea name="admin_note" placeholder="Add a note to send with your decision..." style="min-height:80px;"></textarea>
        </div>
        <div style="display:flex;gap:12px;">
          <button type="submit" name="action" value="approved" class="btn btn-primary" style="flex:1;"
                  onclick="return confirm('Approve this claim? The item status will be updated to Claimed.')">
            ✓ Approve Claim
          </button>
          <button type="submit" name="action" value="rejected" class="btn btn-danger" style="flex:1;"
                  onclick="return confirm('Reject this claim?')">
            ✗ Reject Claim
          </button>
        </div>
      </form>
    </div>
    <?php else: ?>
    <div class="alert alert-info">This claim has already been <?= $claim['status'] ?>
      <?php if ($claim['reviewed_at']): ?> on <?= date('F d, Y', strtotime($claim['reviewed_at'])) ?><?php endif; ?>.
    </div>
    <?php endif; ?>
  </div>

  <div class="card" style="height:fit-content;">
    <div class="card-header"><h2 class="card-title" style="font-size:18px;">Item Status</h2></div>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
      <span class="badge badge-<?= $claim['item_status'] ?>"><?= ucfirst(str_replace('_',' ',$claim['item_status'])) ?></span>
    </div>
    <a href="/admin/item-view.php?id=<?= $claim['item_id'] ?>" class="btn btn-ghost btn-sm" style="width:100%">View Full Item →</a>
  </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>