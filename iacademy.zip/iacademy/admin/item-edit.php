<?php
// ============================================
// iAcademy Lost & Found — Admin Edit Item
// admin/item-edit.php
// ============================================

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
requireLogin('admin');

$pdo = getPDO();
$id  = (int)($_GET['id'] ?? 0);
$error = '';

$item = $pdo->prepare("SELECT * FROM items WHERE id = ?");
$item->execute([$id]);
$item = $item->fetch();
if (!$item) { header('Location: /admin/items.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name      = trim($_POST['item_name']      ?? '');
    $category_id    = (int)($_POST['category_id']   ?? 0);
    $description    = trim($_POST['description']    ?? '');
    $location_found = trim($_POST['location_found'] ?? '');
    $date_reported  = $_POST['date_reported']       ?? '';
    $date_found     = $_POST['date_found']          ?? null;
    $status         = $_POST['status']              ?? 'found';

    if (!$item_name || !$category_id) {
        $error = 'Item name and category are required.';
    } else {
        $pdo->prepare(
            "UPDATE items SET item_name=?, category_id=?, description=?, location_found=?,
             date_reported=?, date_found=?, status=? WHERE id=?"
        )->execute([$item_name, $category_id, $description, $location_found ?: null,
                    $date_reported, $date_found ?: null, $status, $id]);

        // ---> AUTOMATED NOTIFICATION LOGIC <---
        // Check if the status actually changed during the edit
        if ($item['status'] !== $status) {
            $statusName = ucfirst(str_replace('_', ' ', $status));
            $notifTitle = "Item Status Update: {$statusName}";
            $notifMsg   = "The status of your reported item \"{$item_name}\" has been updated to {$statusName}.";
            
            // Send the notification to the person who reported it
            $pdo->prepare(
                "INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)"
            )->execute([$item['reported_by'], $notifTitle, $notifMsg, 'info', '/user/item-view.php?id=' . $id]);
        }

        // New images
        if (!empty($_FILES['images']['name'][0])) {
            $uploadDir = __DIR__ . '/../uploads/items/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            foreach ($_FILES['images']['tmp_name'] as $idx => $tmp) {
                if (!$tmp) continue;
                $ext   = pathinfo($_FILES['images']['name'][$idx], PATHINFO_EXTENSION);
                $fname = $id . '_' . $idx . '_' . time() . '.' . strtolower($ext);
                if (move_uploaded_file($tmp, $uploadDir . $fname)) {
                    $pdo->prepare("INSERT INTO item_images (item_id, image_path, is_primary) VALUES (?,?,0)")
                        ->execute([$id, 'uploads/items/' . $fname]);
                }
            }
        }

        $user = currentUser();
        $pdo->prepare("INSERT INTO activity_log (actor_id, action, target_type, target_id, ip_address) VALUES (?,'item.update','item',?,?)")
            ->execute([$user['id'], $id, $_SERVER['REMOTE_ADDR'] ?? null]);

        header('Location: /admin/item-view.php?id=' . $id . '&updated=1');
        exit;
    }
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$images = $pdo->prepare("SELECT * FROM item_images WHERE item_id = ? ORDER BY is_primary DESC");
$images->execute([$id]); $images = $images->fetchAll();
$statuses = ['lost','found','claimed','turned_in','disposed'];
$pageTitle = 'Edit Item';
include __DIR__ . '/../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="max-width:760px;">
  <div class="card">
    <div class="card-header" style="margin-bottom:24px;">
      <h2 class="card-title">Edit Item</h2>
      <a href="/admin/item-view.php?id=<?= $id ?>" class="btn btn-ghost btn-sm">← Back</a>
    </div>

    <form method="POST" enctype="multipart/form-data">
      <div class="grid-2">
        <div class="field">
          <label>Item Name *</label>
          <input type="text" name="item_name" required value="<?= htmlspecialchars($_POST['item_name'] ?? $item['item_name']) ?>">
        </div>
        <div class="field">
          <label>Category *</label>
          <select name="category_id" required>
            <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= (($_POST['category_id'] ?? $item['category_id']) == $cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="field">
        <label>Description</label>
        <textarea name="description"><?= htmlspecialchars($_POST['description'] ?? $item['description'] ?? '') ?></textarea>
      </div>

      <div class="grid-2">
        <div class="field">
          <label>Location Found</label>
          <input type="text" name="location_found" value="<?= htmlspecialchars($_POST['location_found'] ?? $item['location_found'] ?? '') ?>">
        </div>
        <div class="field">
          <label>Status</label>
          <select name="status">
            <?php foreach ($statuses as $s): ?>
            <option value="<?= $s ?>" <?= (($_POST['status'] ?? $item['status']) === $s) ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="grid-2">
        <div class="field">
          <label>Date Reported</label>
          <input type="date" name="date_reported" value="<?= htmlspecialchars($_POST['date_reported'] ?? $item['date_reported']) ?>">
        </div>
        <div class="field">
          <label>Date Found</label>